#pragma once
#include <vector>
#include <algorithm>
#include <iterator>
#include <iostream>
#include <exception>
#include <stdexcept>
#include <string>

#include "types.h"

namespace graph {
	class vertex_descriptor {
	private:
		vertex_label_t label;
		std::vector<vertex_label_t> successors;
		//bool _successors_loaded;

	public:
		vertex_descriptor() { //_successors_loaded = false; 
		}

		vertex_descriptor(vertex_label_t l) {
			label = l;
			//_successors_loaded = false;
		}

		operator vertex_label_t() const {
			return label;
		}

		friend std::ostream& operator << (std::ostream& out, const vertex_descriptor& v);

		bool operator == (const vertex_descriptor& rhs) const {
			return label == rhs.label && successors == rhs.successors;
		}

		//bool successors_loaded()const { return _successors_loaded; }
		//void successors_loaded(bool sl) { _successors_loaded = sl; }


		const vertex_label_t& get_label()const { return label; }
		vertex_label_t& label_ref() { return label; }


		const std::vector<vertex_label_t>& get_successors() const {
			if (successors.size()>0) {
				return successors;
			}
			else {
				throw
					std::logic_error("Attempt to get successors of descriptor which does not have them loaded.");
			}
		}

	
		std::vector<vertex_label_t>& successors_ref() {
			//_successors_loaded = true;
			return successors;
		}

		std::string as_str() const;
	};

	class virtual_vertex_descriptor: public vertex_descriptor {

	};//
}