#include "vertex.h"

#include <iostream>
#include <iterator>
#include <algorithm>
#include <sstream>

namespace graph {

	std::ostream & operator << (std::ostream & out, const vertex_descriptor & v)
	{
		out << v.label;
		return out;
	}

	std::string vertex_descriptor::as_str() const {
		using namespace std;

		ostringstream o;

		o << label << " : ";
		copy(successors.begin(), successors.end(),
			ostream_iterator<vertex_label_t>(o, " "));

		return o.str();
	}
}
