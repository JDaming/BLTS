#include "iocount.h"

namespace graph {
#ifdef DEBUG
	long int io_num = 0;
	long int io_read = 0;
	long int io_write = 0;

	extern long int tree_edge_num = 0;
#endif // DEBUG
}