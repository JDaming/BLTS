#pragma once
#ifndef OUTPUT_BITSTREAM_HPP
#define OUTPUT_BITSTREAM_HPP

#include <iostream>
#include <vector>
#include <fstream>
#include <cassert>

#include <boost/shared_ptr.hpp>

#include "types.h"

namespace graph {
	class obitstream {
	public:
		/* The default size of the byte buffer in bytes (16Ki). */
		const static int DEFAULT_BUFFER_SIZE = 16 * 1024;

	protected:
		boost::shared_ptr<std::ostream> os;
		/** The number of bits written to this bit stream. */
		long written_bits;
		/** Current bit buffer. */
		int current;
		//   std::vector<bool> current_byte;
		/** The stream buffer. */
		boost::shared_ptr<std::vector<byte> > buffer;
		/** Current number of free bits in the bit buffer (the bits in the buffer are stored high). */
		int free;
		/** Current position in the byte buffer. */
		int pos;
		/** Current position of the underlying output stream. */
		long position;
		/** Current number of bytes available in the byte buffer. */
		int avail;
		/** Size of the small buffer for temporary usage. */
		const static int TEMP_BUFFER_SIZE = 128;
		/** True if we are wrapping an array. */
		bool wrapping;

		/** true iff we have no buffer */
		bool no_buffer;

	private:
		/** Small buffer for temporary usage. */
		std::vector<byte> temp_buffer;

		/**
		* Initialization function that sets everything to sensible default values
		*/
		void init() {
			written_bits = 0;
			current = 0;
			free = 8;
			pos = 0;
			position = 0;
			avail = 0;
			wrapping = false;
			no_buffer = true;
			temp_buffer.resize(TEMP_BUFFER_SIZE);
	};

		void init(const boost::shared_ptr<std::ostream>& os, const int buf_size) {
			init();

			this->os = os;

			if (buf_size != 0) {
				buffer->resize(buf_size);
				avail = buf_size;
				no_buffer = false;
			}
			else {
				avail = 0;
				no_buffer = true;
			}
		}

	protected:
		obitstream() {
			init();
		}

	public:

		/** Creates a new output bit stream wrapping a given output stream with a specified buffer size.
		*
		* @param os the output stream to wrap.
		*/
		obitstream(const boost::shared_ptr<std::ostream>& os, const int buf_size = DEFAULT_BUFFER_SIZE) :
			buffer((buf_size == 0) ? NULL : new std::vector<byte>(buf_size)) {
			init(os, buf_size);
		}


		/* Creates a new output bit stream wrapping a given byte array.
		*
		* TODO find alternative to copying whole array.
		*
		* @param a the byte array to wrap.
		*/
		obitstream(boost::shared_ptr<std::vector<byte> >& a) : buffer(a) {
			init();

			free = 8;
			avail = a->capacity();
			wrapping = true;
		}


		/** Creates a new output bit stream writing to file.
		*
		* @param name the name of the file.
		* @param bufSize the size in byte of the buffer; it may be 0, denoting no buffering.
		*/
		obitstream(const std::string name, const int buf_size = DEFAULT_BUFFER_SIZE) :
			buffer((buf_size == 0) ? NULL : new std::vector<byte>(buf_size)) {
			boost::shared_ptr<std::ostream> o(new std::ofstream(name.c_str()));
			init(o, buf_size);
		}

		~obitstream() {
			// make sure everything makes it to the file.
			flush();
		}

		void flush() {
			align();
			if (os != NULL) {
				if (!no_buffer) {
					os->write((char*)&(*buffer)[0], pos);
					position += pos;
					pos = 0;
					avail = buffer->size();
				}
				os->flush();
			}
		}

		long get_written_bits() {
			return written_bits;
		}

		void set_written_bits(const long written_bits) {
			this->written_bits = written_bits;
		}

	private:
		void write(const int b);
		int write_in_current(const int b, const int len);

	public:
		int align() {

			if (free != 8)
				return write_in_current(0, free);
			else
				return 0;
		}
		void set_position(const long position);
		int write(const byte bits[], const int len) {
			return write_byte_offset(bits, 0, len);
		}
		int write(const byte bits[], const int offset, const int len);
		
	protected:
		int write_byte_offset(const byte bits[],
			const int offset, int len);
		int write_bit(const bool bit) {
			return write_in_current(bit ? 1 : 0, 1);
		}
		int write_bit(const int  bit) {
			assert(bit == 0 || bit == 1);
			return write_in_current(bit, 1);
		}

	public:
		int write_int(int x, const int len);
		int write_unary(int x);
};

}


#endif
