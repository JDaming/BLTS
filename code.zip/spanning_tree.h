#pragma once
#include <string>
#include <vector>
#include <utility>
#include <climits>
#include <tr1/unordered_map>
#include "types.h"
#include "offline_graph.h"


namespace graph {

	class in_memory_vertex_descriptor {
	private:
		vertex_label_t label;
		long int index;
		long int parent;
		std::vector<in_memory_vertex_descriptor* > successors;
	public:
		in_memory_vertex_descriptor() { //_successors_loaded = false; 

		}

		in_memory_vertex_descriptor(vertex_label_t l) {
			label = l;
			//_successors_loaded = false;
		}
		~in_memory_vertex_descriptor() {
			successors.clear();
			std::vector<in_memory_vertex_descriptor*>().swap(successors);
		}
		operator vertex_label_t() const {
			return label;
		}

		//friend std::ostream& operator << (std::ostream& out, const in_memory_vertex_descriptor& v);

		bool operator == (const in_memory_vertex_descriptor& rhs) const  {
			return label == rhs.label && successors == rhs.successors;
		}
		in_memory_vertex_descriptor& operator = (in_memory_vertex_descriptor& rhs){
			this->label = rhs.get_label();
			this->index = rhs.get_index();
			this->parent = rhs.get_parent();
			this->successors_ref().clear();
			this->successors.insert(this->successors.end(), rhs.successors_ref().begin(), rhs.successors_ref().end());
			return *this;
		}


		//bool successors_loaded()const { return _successors_loaded; }
		//void successors_loaded(bool sl) { _successors_loaded = sl; }


		const vertex_label_t& get_label()const { return this->label; }
		vertex_label_t& label_ref() { return this->label; }
		const vertex_label_t& get_index()const { return this->index; }
		vertex_label_t& index_ref() { return this->index; }
		const vertex_label_t& get_parent()const { return this->parent; }
		vertex_label_t& parent_ref() { return this->parent; }


		const std::vector<in_memory_vertex_descriptor* >& get_successors() const {
			if (successors.size()>0) {
				return successors;
			}
			else {
				throw
					std::logic_error("Attempt to get successors of descriptor which does not have them loaded.");
			}
		}


		std::vector<in_memory_vertex_descriptor* >& successors_ref() {
			//_successors_loaded = true;
			return successors;
		}

	};

	class spanning_tree {
	public:
		//typedef boost::adjacency_list<boost::vecS, boost::vecS, boost::directedS> graph_type;
		//graph_type spt;
		
		//std::vector<vertex_descriptor> vertex_list;
		long int num_vertices;


		in_memory_vertex_descriptor root; //virtual node, root of spanning tree
		std::vector<in_memory_vertex_descriptor* > vertex_list;
	
		std::tr1::unordered_map<vertex_label_t, int> vertex_map;
	public:
		spanning_tree() {
			root.label_ref() = ROOT_SIGN;
			num_vertices = 0;
		}
		spanning_tree(int n):num_vertices(n) {
			root.label_ref() = ROOT_SIGN;
			vertex_list.resize(n);
		}

		 ~spanning_tree() {
			 vertex_list.clear();
			 vertex_map.clear();
			 std::vector<in_memory_vertex_descriptor*>().swap(vertex_list);
			 std::tr1::unordered_map<vertex_label_t, int>().swap(vertex_map);
		}
		void add_vertex(in_memory_vertex_descriptor* u) {
			vertex_list.push_back(u);
			vertex_map.insert(std::pair<vertex_label_t, int>(u->get_label(), num_vertices));
			num_vertices++;
			
		}
		spanning_tree& operator = (spanning_tree& rhs) {
			this->num_vertices = rhs.num_vertices;
			this->root = rhs.root;
			this->vertex_list.insert(this ->vertex_list.end(), rhs.vertex_list.begin(), rhs.vertex_list.end());
			this->vertex_map = rhs.vertex_map;
			//this->vertex_list.insert(vertex_list.begin(), rhs.vertex_list.begin(), rhs.vertex_list.end()); 
			return *this;
		}

		void generate(offline_graph& me);
		
	};

}


