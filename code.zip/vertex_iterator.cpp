#include "vertex_iterator.h"
#include "iocount.h"

#include <sstream>
#include <iterator>
#include <algorithm>


namespace graph {
	vertex_iterator::vertex_iterator() {
		init();
		end_marker = true;
	}

	vertex_iterator::vertex_iterator(const char* filename) {
		init();

		this->filename = filename;
		back = fopen(filename,"r");
		if (back == NULL) {
			perror(filename);
			exit(EXIT_FAILURE);
		}
		end_marker = false;

		//std::string tmp;
		//getline(back, tmp); 

		//std::istringstream iss(tmp);

		//iss >> num_vertices;

		//current_descriptor.label_ref() = 0;

		increment();
		 
		//current_descriptor.label_ref() = 0;
	}

	vertex_iterator::vertex_iterator(const vertex_iterator& that ) {
		init();
		copy(that);
	}

	vertex_iterator& vertex_iterator::operator = (const vertex_iterator& rhs) {
		copy(rhs);
		return *this;
	}

	void vertex_iterator::copy(const vertex_iterator& other) {
		if (other.end_marker) {
			if (back != NULL) {
				fclose(back);
				back = NULL;
			}
			end_marker = true;
		}
		else {
			current_descriptor = other.current_descriptor;
			if (back != NULL) {
				fclose(back);
				back = NULL;
			}
				

			filename = other.filename;

			back = fopen(filename.c_str(),"r");
			if (back == NULL) {
				perror(filename.c_str());
				exit(EXIT_FAILURE);
			}
			fseek(back,other.get_pos,SEEK_SET);
			get_pos = other.get_pos;
			num_vertices = other.num_vertices;
			end_marker = false;
			

			//fclose(other.back);
		}

	}


	void vertex_iterator::increment() {
		//std::string tmp;
		
		size_t len = 0;

		char* line = NULL;
		ssize_t nread;

		nread = getline(&line,&len,back);
#ifdef DEBUG
		io_num += nread;
		io_read += nread;
#endif // DEBUG
		if (nread == -1) {
			end_marker = true;
			return;
		}

		current_descriptor.successors_ref().clear();
		
		std::stringstream iss(line);
		iss >> current_descriptor.label_ref();

		std::copy(std::istream_iterator<vertex_label_t>(iss), std::istream_iterator<vertex_label_t>(), std::back_inserter(current_descriptor.successors_ref()));
		//iss >> current_descriptor.successors_ref();
		get_pos = ftell(back);
		free(line);
		iss.str(std::string());
	}

	std::string vertex_iterator::as_str() const {
		std::ostringstream o;

		o << "ascii_graph::offline_vertex_iterator\n"
			<< "\tcurrent_descriptor:\n\t" << current_descriptor.as_str() << "\n"
			<< "\tfilename: " << filename << "\n"
			<< "\tseek position: " << get_pos << "\n"
			<< "\tis end marker?: " << end_marker << "\n";

		return o.str();
	}

	vertex_iterator::~vertex_iterator() {

	}

	int outdegree(const vertex_iterator& me) {
		return me.current_descriptor.get_successors().size();
	}

	const std::vector<vertex_label_t>& successors(const vertex_iterator& me) {
		return me.current_descriptor.get_successors();
	}

}