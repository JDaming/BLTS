#include "edge.h"

namespace graph {

	std::ostream& operator << (std::ostream& out, const edge& e) {
		out << e.first.get_label() << " " << e.second.get_label() << std::endl;
		return out;
	}

}