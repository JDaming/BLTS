#pragma once
#include "vertex.h"

#include <utility>
#include <iostream>

namespace graph {
	
		typedef std::pair<vertex_descriptor, vertex_descriptor> edge;

		std::ostream& operator << (std::ostream& out, const edge& e);
	}
