#include "EdgeByBatch.h"
#include <boost/graph/depth_first_search.hpp>
#include <boost/graph/graph_traits.hpp>
#include <time.h>

#include "dfs.h"

namespace graph {
	namespace al {
		EdgeByBatch::EdgeByBatch() {

		}
		EdgeByBatch::EdgeByBatch(spanning_tree& tree,int memory_size, std::string file)
		{
			T = tree;
			filename = file;
			window_size = memory_size;
		}
		EdgeByBatch::EdgeByBatch(offline_graph g,int memory_size) {
			window_size = memory_size;
			//edge_memory.resize(window_size / sizeof(edge));
#ifdef DEBUG
			std::cout << "window_size:" << window_size << std::endl;
#endif
			filename = g.filename;
			T.generate(g);


		}
		
		/*
		bool EdgeByBatch::is_forward_cross_edge(edge e)
		{
			dfs dfs_vistor(T.num_vertices);

			return dfs_vistor.is_forward_cross_edge(e);
		}*/
		bool EdgeByBatch::restructure(spanning_tree & tree)
		{
			bool update = false;
			bool flag;

			edge_iterator  begin(filename.c_str()), end;
			dfs dfs_visitor1(tree.num_vertices);
			std::vector<edge > edge_memory;
			edge_memory.resize(window_size);
			int pos = 0;

			for (edge_iterator itor = begin; itor != end; ++itor) {
				flag = false;
				edge_memory[pos++] = *itor;
				if (pos == window_size) {
					dfs_visitor1.dfs_tree(tree);
					int s_index, e_index;
					//std::cout << edge_memory_ptr->size() << std::endl;
					for (size_t i = 0; i < edge_memory.size(); i++) {
#ifdef DEBUG
						//std::cout <<i<<":"<< edge_memory[i].first.get_label() << " " << edge_memory[i].second.get_label() << std::endl;
						
#endif
						std::tr1::unordered_map<vertex_label_t, int>::iterator hm_itor1, hm_itor2;
						hm_itor1 = tree.vertex_map.find(edge_memory[i].first.get_label());
						hm_itor2 = tree.vertex_map.find(edge_memory[i].second.get_label());
						s_index = hm_itor1->second;
						e_index = hm_itor2->second;

						if (dfs_visitor1.is_forward_cross_edge(s_index, e_index)) {
							update = true;
							flag = true;
							break;
						}


					}
					if (flag == true) {
						for (size_t i = 0; i < edge_memory.size(); i++) {
							tree.vertex_list[s_index]->successors_ref().push_back(tree.vertex_list[e_index]);
							tree.vertex_list[e_index]->parent_ref() = s_index;
						}

						dfs_visitor1.dfs_tree(tree);
						//DFS
					}
					//std::vector<edge>().swap(edge_memory);
					dfs_visitor1.free_space();
					pos = 0;
					//delete &dfs_visitor1;
					
				}
			}

			//handle left edge;

			if (pos > 0) {
				dfs_visitor1.dfs_tree(tree);
				int s_index, e_index;
				for (size_t i = 0; i < pos; i++) {
					std::tr1::unordered_map<vertex_label_t, int>::iterator hm_itor1, hm_itor2;
					hm_itor1 = tree.vertex_map.find(edge_memory[i].first.get_label());
					hm_itor2 = tree.vertex_map.find(edge_memory[i].second.get_label());
					s_index = hm_itor1->second;
					e_index = hm_itor2->second;
					if (dfs_visitor1.is_forward_cross_edge(s_index, e_index)) {
						update = true;
						flag = true;
						break;
					}
				}
				if (flag == true) {
					for (size_t i = 0; i < edge_memory.size(); i++) {
						tree.vertex_list[s_index]->successors_ref().push_back(tree.vertex_list[e_index]);
						tree.vertex_list[e_index]->parent_ref() = s_index;
					}
					dfs_visitor1.dfs_tree(tree);
					//DFS
				}

				
				dfs_visitor1.free_space();
			}
			std::vector<edge>().swap(edge_memory);
			return update;
		}
		bool EdgeByBatch::restructure()
		{
			bool update = false;
			bool flag ;
#ifdef DEBUG
			clock_t start = clock();
#endif // DEBUG

			edge_iterator  begin(filename.c_str()), end;
			dfs dfs_visitor1(T.num_vertices);
			std::vector<edge > edge_memory(window_size);
			
			int pos = 0;
			for (edge_iterator itor = begin; itor != end; ++itor) {
				flag = false;
				edge_memory[pos++]= *itor;
			
				if (pos == window_size ) {
					
					dfs_visitor1.dfs_tree(T);
					//int s_index, e_index;
					for (size_t i = 0; i < edge_memory.size(); i++) {
						/*
						for (size_t j = 0; j < T.num_vertices; j++) {
							if (T.vertex_list[j]->get_label() == edge_memory[i].first)
								s_index = j;
							if (T.vertex_list[j]->get_label() == edge_memory[i].second)
								e_index = j;
						}*/
						if (dfs_visitor1.is_forward_cross_edge(edge_memory[i].first.get_label(), edge_memory[i].second.get_label())) {
							update = true;
							flag = true;
							break;
						}
						
								
					}
					if (flag == true) {
						for (size_t i = 0; i < edge_memory.size(); i++) {
							T.vertex_list[edge_memory[i].first.get_label()]->successors_ref().push_back(T.vertex_list[edge_memory[i].second.get_label()]);
						}
						for (size_t i = 0; i < T.num_vertices; i++)
							std::vector<in_memory_vertex_descriptor*>(T.vertex_list[i]->successors_ref()).swap(T.vertex_list[i]->successors_ref());
						
						dfs_visitor1.dfs_tree(T);
						
						//DFS
						
						
					}
					
					dfs_visitor1.free_space();
					pos = 0;
				}
				
			}
			//handle left edge;

			if (pos > 0) {
				dfs_visitor1.dfs_tree(T);
				for (size_t i = 0; i < pos; i++) {
					if (dfs_visitor1.is_forward_cross_edge(edge_memory[i].first.get_label(), edge_memory[i].second.get_label())) {
						update = true;
						flag = true;
						break;
					}
				}
				if (flag == true) {
					for (size_t i = 0; i < edge_memory.size(); i++) {
						T.vertex_list[edge_memory[i].first.get_label()]->successors_ref().push_back(T.vertex_list[edge_memory[i].second.get_label()]);
					}
					dfs_visitor1.dfs_tree(T);
					//DFS
					for (size_t i = 0; i < T.num_vertices; i++)
						std::vector<in_memory_vertex_descriptor*>(T.vertex_list[i]->successors_ref()).swap(T.vertex_list[i]->successors_ref());
					//DF
				}

				
				dfs_visitor1.free_space();
			}

			std::vector<edge>().swap(edge_memory);
#ifdef DEBUG
			clock_t end_time = clock();
			
			std::cout << "time:" << (double)(end_time - start) / CLOCKS_PER_SEC << "s" << std::endl;
			std::cout << "iteration over;" << std::endl;
#endif
			return update;

		}


		bool EdgeByBatch::edgebyedge()
		{
			bool update = false;
			bool flag;

			edge_iterator  begin(filename.c_str()), end;
			dfs dfs_visitor1(T.num_vertices);
			dfs_visitor1.dfs_tree(T);
			for (edge_iterator itor = begin; itor != end; ++itor) {
				flag = false;
				bool tmp_flag = false;
				//edge_memory_ptr->push_back(*itor);
				if (dfs_visitor1.is_forward_cross_edge(itor->first.get_label(), itor->second.get_label())) {
					flag = true;
					update = true;
					in_memory_vertex_descriptor* w = T.vertex_list[T.vertex_list[itor->second.get_label()]->get_parent()];
					for (size_t i = 0; i < w->successors_ref().size(); i++) {
						if (w->successors_ref()[i]->get_label() == itor->second.get_label()) {
							T.vertex_list[T.vertex_list[itor->second.get_label()]->get_parent()]->successors_ref().erase(T.vertex_list[T.vertex_list[itor->second.get_label()]->get_parent()]->successors_ref().begin() + i);
							std::vector<in_memory_vertex_descriptor* >(T.vertex_list[i]->successors_ref()).swap(T.vertex_list[i]->successors_ref());
							break;
						}
					}
					

					T.vertex_list[itor->first.get_label()]->successors_ref().push_back(T.vertex_list[itor->second.get_label()]);
					std::vector<in_memory_vertex_descriptor* >(T.vertex_list[itor->first.get_label()]->successors_ref()).swap(T.vertex_list[itor->first.get_label()]->successors_ref());
				}
			
			}
#ifdef DEBUG
			std::cout << "iteration over;" << std::endl;
#endif
			return update;
		}
	
	}
}



