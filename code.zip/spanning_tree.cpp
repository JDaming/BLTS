#include <sstream>
#include <iostream>



#include "spanning_tree.h"
#include "edge_iterator.h"


namespace graph {
	
	void  spanning_tree::generate(offline_graph& me)
	{
		//spanning_tree T;
		//graph_type tmp(me.get_num_nodes());
		
		//spt = tmp;
		num_vertices = me.get_num_nodes()+1;
		vertex_list.resize(me.get_num_nodes()+1);
		for (size_t i = 0; i < vertex_list.size(); i++) {
			vertex_list[i] = new in_memory_vertex_descriptor();
			vertex_list[i]->label_ref() = i;
			vertex_list[i]->index_ref() = i;
			vertex_map.insert(std::pair<vertex_label_t, int>(i,i));
		}
			
		edge_iterator begin, end;

		tie(begin, end) = me.get_edge_iterator();

		//in_memory_vertex_descriptor* last_vertex = new in_memory_vertex_descriptor();
		//in_memory_vertex_descriptor* s = new in_memory_vertex_descriptor();

		
		//last_vertex->label_ref() = VIRTUAL_SIGN;
		//s->label_ref() = VIRTUAL_SIGN;
		root.label_ref() = ROOT_SIGN;
		root.index_ref() = 0;
		bool* status = new bool[vertex_list.size()];
		for (size_t i = 0; i < vertex_list.size(); i++) {
			status[i] = true;
		}
		
		for (edge_iterator itor = begin; itor != end; ++itor) {


			if (status[itor->second.get_label()] == true) {
				vertex_list[itor->first.get_label()]->successors_ref().push_back(vertex_list[itor->second.get_label()]);
				vertex_list[itor->second.get_label()]->parent_ref() = itor->first.get_label();
				status[itor->second.get_label()] = false;
			}	
		} 

		for (size_t i = 1; i < vertex_list.size(); i++) {
			if (status[i] == true) {
				root.successors_ref().push_back(vertex_list[i]);
				vertex_list[i]->parent_ref() = 0;
			}
		}

		vertex_list[0] = &root;
		delete[]status;

		for (size_t i = 0; i < vertex_list.size(); i++)
			std::vector<in_memory_vertex_descriptor*>(vertex_list[i]->successors_ref()).swap(vertex_list[i]->successors_ref());
	}
	
}