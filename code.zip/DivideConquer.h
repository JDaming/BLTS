#pragma once
#include <iostream>
#include <utility>
#include <algorithm>
#include <vector>

#include <boost/shared_ptr.hpp>


#include "types.h"
#include "spanning_tree.h"
#include "offline_graph.h"
#include "edge.h"
#include "vertex.h"
#include "dfs.h"


namespace graph {
	namespace al {
		typedef offline_graph graph_type;
	
		typedef std::pair<vertex_label_t, vertex_label_t> edge_type;
		
		/*
		class in_memory_vertex_descriptor{
		
		private:
			vertex_label_t label;
			std::vector<in_memory_vertex_descriptor* > successors;
			int index;
		public:
			in_memory_vertex_descriptor() { //_successors_loaded = false; 
			}

			in_memory_vertex_descriptor(vertex_label_t l) {
				label = l;
				//_successors_loaded = false;
			}



			//friend std::ostream& operator << (std::ostream& out, const in_memory_vertex_descriptor& v);

			bool operator == (const in_memory_vertex_descriptor& rhs) const {
				return label == rhs.label && successors == rhs.successors;
			}
			in_memory_vertex_descriptor& operator = (in_memory_vertex_descriptor& rhs) {
				this->label = rhs.get_label();
				this->index = rhs.get_index();
				this->successors_ref().clear();
				this->successors.insert(this->successors.end(), rhs.successors_ref().begin(), rhs.successors_ref().end());
				return *this;
			}

			//bool successors_loaded()const { return _successors_loaded; }
			//void successors_loaded(bool sl) { _successors_loaded = sl; }


			const vertex_label_t& get_label()const { return this->label; }
			vertex_label_t& label_ref() { return this->label; }

			const vertex_label_t& get_index()const { return this->index; }
			vertex_label_t& index_ref() { return this->index; }

			const std::vector<in_memory_vertex_descriptor* >& get_successors() const {
				if (successors.size()>0) {
					return successors;
				}
				else {
					throw
						std::logic_error("Attempt to get successors of descriptor which does not have them loaded.");
				}
			}


			std::vector<in_memory_vertex_descriptor* >& successors_ref() {
				//_successors_loaded = true;
				return successors;
			}
		};
		*/

		class s_graph_type{
		public:
			long int num_vertices;


			in_memory_vertex_descriptor root; //virtual node, root of spanning tree
			std::vector<in_memory_vertex_descriptor* > vertex_list;
			
			
		public:
			s_graph_type() {
				root.label_ref() = ROOT_SIGN;
				num_vertices = 0;
			}
			s_graph_type(int n) :num_vertices(n) {
				root.label_ref() = ROOT_SIGN;
				vertex_list.resize(n);
			}

			virtual ~s_graph_type() {}

			s_graph_type& operator = (s_graph_type rhs) {
				this->num_vertices = rhs.num_vertices;
				this->root = rhs.root;
				this->vertex_list.clear();
				this->vertex_list.insert(vertex_list.begin(), rhs.vertex_list.begin(), rhs.vertex_list.end());
				return *this;
			}

			void add_vertex(in_memory_vertex_descriptor* v) {
				vertex_list.push_back(v);
				num_vertices++;
			}
			void dfs_node(int index, std::vector<vertex_label_t>& order, std::vector<color>& status, bool& flag)
			{

				status[index] = gray;

				std::vector<in_memory_vertex_descriptor* > outedges = vertex_list[index]->successors_ref();
				int out_degree = outedges.size();
				for (size_t i = 0; i < out_degree; i++) {
					int pos = outedges[i]->get_index();
					switch (status[pos]) {
					case white:
						dfs_node(outedges[i]->get_index(), order, status, flag);
						break;
					case gray:
						flag = true;
						break;
					case black:
						flag = true;
						break;

					}
				}

				status[index] = black;
				order.push_back(index);
			}
			
			void dfs_node(int index, std::vector<vertex_label_t>& order, std::vector<color>& status, std::tr1::unordered_map<vertex_label_t, int>& map)
			{

				status[index] = gray;

				std::vector<in_memory_vertex_descriptor* > outedges = vertex_list[index]->successors_ref();
				int out_degree = outedges.size();
				for (size_t i = 0; i < out_degree; i++) {
					int pos = outedges[i]->get_index();
					
					switch (status[pos]) {
					case white:
						dfs_node(outedges[i]->get_index(), order, status, map);
						break;
					case gray:
						break;
					case black:		
						break;

					}
				}
				
				status[index] = black;
				
				order.push_back(index);
				map.insert(std::pair<vertex_label_t,int>(vertex_list[index]->get_label(), order.size() - 1));
			}

			void scc_dfs_node(int index, std::vector<vertex_label_t>& component, std::vector<color>& status) {
				status[index] = gray;
				component.push_back(vertex_list[index]->get_label());
				std::vector<in_memory_vertex_descriptor* > outedges = vertex_list[index]->successors_ref();
				int out_degree = outedges.size();
				for (size_t i = 0; i < out_degree; i++) {
					int pos = outedges[i]->get_index();
					switch (status[pos]) {
					case white:
						scc_dfs_node(outedges[i]->get_index(), component, status);
						break;
					case gray:
						break;
					case black:
						break;
						

					}
				}
				status[index] = black;
			}

			
		};
		class DivideConquer {
		private:
			
			const static int STD_BUFFER_SIZE = 1024 * 1024;
			int window_size;

			

			bool dividable;
		public:
			spanning_tree T;
			std::string filename;
			DivideConquer();
			DivideConquer(offline_graph o, int memory_size);
			DivideConquer(int memory_size, spanning_tree& tree);

			void DivideConquerDFS(spanning_tree& tree, graph_type& g);
	

			
		};


		class Divide {
			//typedef boost::adjacency_list<boost::vecS, boost::vecS, boost::directedS> graph_type;
			
			int memory;
		private:
			std::string filename;
			
			s_graph_type s_graph;

			

		public:
			int scc_num;
			spanning_tree T;
			std::vector<graph_type > subgraphs;
			std::vector<spanning_tree > subtrees;

			//initial T and s_graph
			//Divide();
			Divide(spanning_tree& tree, std::string file, int m);
			edge_type s_edge(edge_type e, vertex_label_t p, dfs & dfs_visitor);
			vertex_label_t pushup(vertex_label_t u, vertex_label_t p, dfs& dfs_visitor);

			bool is_ancestor(in_memory_vertex_descriptor * & u, vertex_label_t v, dfs& dfs_visitor);
			int is_in_graph(vertex_label_t u, spanning_tree& t);
			bool is_nonleaf_node(vertex_label_t u, spanning_tree& t);
			void leaf_node(spanning_tree tree, std::vector<in_memory_vertex_descriptor* >& leafs, spanning_tree & T);
			int in_which_subgraph(vertex_label_t u);
			void divide_TD();
			void merge(spanning_tree& tree); 
		};

		
		
}

}