#include "dfs.h"

namespace graph {
	namespace al {
		graph::al::dfs::dfs()
		{
		}

		graph::al::dfs::dfs(int n):num_vertices(n)
		{
			status.assign(num_vertices, white);
			dtime.assign(num_vertices, -1);
			ftime.assign(num_vertices, -1);
			height.assign(num_vertices, -1);
		}
		/*
		dfs::tree_type dfs::dfs_tree(graph_type& g)
		{
			tree_type tree(num_vertices);
			status.assign(num_vertices, white);
			dtime.assign(num_vertices, -1);
			ftime.assign(num_vertices, -1);

			Time_type clock = 0;
			int index = 0;
			
			while (index != num_vertices) {
				if (status[index] == white)
					dfs_node(index, clock,tree, g);
				index++;
			}
			return tree;
		}
		*/
		void dfs::dfs_lca(graph_type& g, std::vector<int> &euler_tour) {
			num_vertices = g.num_vertices;
			status.assign(num_vertices, white);
			dtime.assign(num_vertices, -1);
			ftime.assign(num_vertices, -1);
			etime.assign(num_vertices, -1);

			Time_type clock = 0;
			int index = 0;
			while (index != num_vertices) {
				if (status[index] == white)
					dfs_node(g.vertex_list[index], clock,  -1, euler_tour);
				index++;
			}

			
		}
		void dfs::dfs_tree(graph_type& g) {
			num_vertices = g.num_vertices;
			status.assign(num_vertices, white);
			dtime.assign(num_vertices, -1);
			ftime.assign(num_vertices, -1);

			Time_type clock = 0;
			int index = 0;
			while (index != num_vertices) {
				if(status[index] == white)
					dfs_node(g.vertex_list[index], clock);
				index++;
			}

			
		
	;
		}
		/*
		void dfs::dfs_travelling(graph_type & g)
		{

		}*/

		
		bool dfs::is_forward_cross_edge(int s_index, int e_index)
		{
			if(dtime[s_index]<dtime[e_index] && (ftime[s_index]<ftime[e_index]))
				return true;
			return false;
		}

		bool dfs::is_backward_edge(int s_index, int e_index)
		{
			if(dtime[s_index]>dtime[e_index] && (ftime[s_index]<ftime[e_index]))
				return true;
			return false;
		}

		
	

		void dfs::dfs_node(in_memory_vertex_descriptor*& u, Time_type& clock)
		{
			status[u->get_index()] = gray;

			dtime[u->get_index()] = ++clock;
			

			for (size_t i = 0; i < u->successors_ref().size(); i++) {
				int pos = u->successors_ref()[i]->get_index();
				switch (status[pos]) {
				case white:
					//tree.vertex_list[index]->label_ref() = index;
					//tree.vertex_list[pos]->label_ref() = pos;
					//tree.vertex_list[index]->successors_ref().push_back(tree.vertex_list[pos]);
					dfs_node(u->successors_ref()[i], clock);
					break;
				case gray:
					//u->successors_ref().erase(u->successors_ref().begin() + i);
					std::swap(u->successors_ref()[i], u->successors_ref()[u->successors_ref().size()-1]);
					u->successors_ref().pop_back();
					i--;
					break;
				case black:
					std::swap(u->successors_ref()[i], u->successors_ref()[u->successors_ref().size()-1]);
					u->successors_ref().pop_back();
					i--;
					break;
				}
			}
			std::vector<in_memory_vertex_descriptor* >(u->successors_ref()).swap(u->successors_ref());
			status[u->get_index()] = black;
			ftime[u->get_index()] = ++clock;

		}

		

		void dfs::dfs_node(in_memory_vertex_descriptor*& u, std::vector<vertex_label_t>& order, bool& flag)
		{
	
			status[u->get_index()] = gray;

			std::vector<in_memory_vertex_descriptor* > outedges = u->get_successors();
			int out_degree = outedges.size();
			for (size_t i = 0; i < out_degree; i++) {
				int pos = outedges[i]->get_index();
				switch (status[pos]) {
				case white:
					dfs_node(u->successors_ref()[i], order, flag);
					break;
				case gray:
					flag = true;

				}
			}
			std::vector<in_memory_vertex_descriptor* >(u->successors_ref()).swap(u->successors_ref());
			status[u->get_index()] = black;
			order.push_back(u->get_index());
		}

		void dfs::dfs_node(in_memory_vertex_descriptor*& u, Time_type& clock, int h, std::vector<int>& euler_tour)
		{
			status[u->get_index()] = gray;
			dtime[u->get_index()] = clock++;
			etime[u->get_index()] = euler_tour.size();
			euler_tour.push_back(u->get_index());
			height[u->get_index()] = ++h;
	
			std::vector<in_memory_vertex_descriptor* > outedges = u->successors_ref();
			int out_degree = outedges.size();
			for (size_t i = 0; i < out_degree; i++) {
				int pos = outedges[i]->get_index();
				switch (status[pos]) {
				case white:
					dfs_node(outedges[i], clock, h, euler_tour);
					euler_tour.push_back(u->get_index());
					break;

				}
			}
			
			std::vector<in_memory_vertex_descriptor* >(u->successors_ref()).swap(u->successors_ref());
			status[u->get_index()] = black;
			ftime[u->get_index()] = clock++;
		}

		bool dfs::is_cross_edge(int s_index, int e_index)
		{
			if ((dtime[s_index]<dtime[e_index] && ftime[s_index]<ftime[e_index]) || (dtime[s_index]>dtime[e_index] && ftime[s_index]>ftime[e_index]))
				return true;
			return false;
		}

		void dfs::free_space()
		{
			std::vector<color>().swap(status);
			std::vector<Time_type>().swap(dtime);
			std::vector<Time_type>().swap(ftime);
		}

		
} }


void graph::al::dfs::dfs_ts(lbtree& T, std::vector<vertex_label_t>& order)
{
	dtime.assign(T.num_nodes, -1);
	status.assign(T.num_nodes, white);
	ftime.assign(T.num_nodes,-1);
	//order.assign(T->num_nodes, -1);
	
	Time_type clock = 0;
	T.node_list[0] = &T.root;
	
	dfs_node(T.node_list[0],order, clock);
	
}

void graph::al::dfs::dfs_travel(lbtree& T)
{
	status.assign(T.num_nodes, white);
	ftime.assign(T.num_nodes, -1);
	dtime.assign(T.num_nodes, -1);
	//order.assign(T->num_nodes, -1);
	
	Time_type clock = 0;
	T.node_list[0] = &T.root;
	
	dfs_travel_node(T.node_list[0], clock);
}

void graph::al::dfs::dfs_node(level_node * & u, std::vector<vertex_label_t>& order, Time_type & clock)
{
	status[u->get_label()] = gray;
	dtime[u->get_label()] = ++clock;
	
	for (size_t i = 0; i < u->successors_ref().size(); i++)
	{
		int pos = u->successors_ref()[i]->get_label();
		switch (status[pos])
		{
		case white:
			dfs_node(u->successors_ref()[i], order, clock);
			break;
			
		}
	}
	status[u->get_label()] = black;
	ftime[u->get_label()] = ++clock;
	order.push_back(u->get_label());

}

void graph::al::dfs::dfs_travel_node(level_node * & u,  Time_type & clock)
{
	status[u->get_label()] = gray;
	dtime[u->get_label()] = ++clock;
	
	for (size_t i = 0; i < u->successors_ref().size(); i++)
	{
		int pos = u->successors_ref()[i]->get_label();
		switch (status[pos])
		{
		case white:
			dfs_travel_node(u->successors_ref()[i],clock);
			break;
			
		}
	}
	status[u->get_label()] = black;
	ftime[u->get_label()] = ++clock;
}

void graph::al::dfs::dfs_ts(spanning_tree & T, std::vector<vertex_label_t>& order)
{
	status.assign(T.num_vertices, white);


	int index = 0;
	for (size_t i = 0; i < T.num_vertices; i++)
	{
		if (status[i] == white)
		{
			dfs_node(T.vertex_list[i], order);
		}
	}

	//std::vector<color>().swap(status);
}

void graph::al::dfs::dfs_node(in_memory_vertex_descriptor *& u, std::vector<vertex_label_t>& order)
{

	status[u->get_label()] = gray;


	for (size_t i = 0; i < u->successors_ref().size(); i++)
	{
		int pos = u->successors_ref()[i]->get_label();
		switch (status[pos])
		{
		case white:
			dfs_node(u->successors_ref()[i], order);
			break;

		}
	}
	status[u->get_label()] = black;

	order.push_back(u->get_label());
}





