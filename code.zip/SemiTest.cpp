#include <iostream>

#include "TS.h"
#include "offline_graph.h"
#include "dfs.h"

int main(int argc, char *argv[])
{
		
	//std::string filename("/home/gaotianpeng/BigData_gaotianpeng/Ts/enwiki-2020-edgelist.txt_no");
	//std::string filename("/home/daming/dblpdag_2");
	//std::string filename("/home/sda/twitter/twitter-2010-2_0.4");
	//std::string filename("/home/hadoop/TS/dblp/dblp-2_0.4");
	std::string filename(argv[1]);

	int memory_size = std::atoi(argv[2]); 
	//float rate = std::atof(argv[2]
	//long int memory_size = 16777216;
	//long int memory_size = 9;
	graph::offline_graph graph_t = graph::offline_graph::load(filename);
	
	//graph::random_generator(graph_t, double(rate));
	//std::cout << "memory_size:" << memory_size << std::endl;
	//graph::preprocessing3(filename);
	
	//graph::dc(graph_t, memory_size);
	//graph::ju_blts(graph_t, memory_size);
 	//graph::blts(graph_t, memory_size);
	//graph::eb(graph_t, memory_size);
	//graph::ee(graph_t,memory_size);
	graph::ilts_it(graph_t, memory_size);
	//graph::nlts(graph_t, memory_size);
	//graph::it_blts(graph_t, memory_size);
	
	return 0;
}