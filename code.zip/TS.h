#include <iostream>
#include <algorithm>
#include <time.h>

#include "in_graph.h"
#include "offline_graph.h"
#include "EdgeByBatch.h"
#include "DivideConquer.h"
#include "preprocess.h"
#include "dfs.h"
#include "iocount.h"

namespace graph {
	
		int eb(offline_graph graph_t, int memory_size)
		{


			//	preprocessing1(graph_t);

				//graph::preprocessing3(filename);

				//graph::preprocessing_dblp(filename);


			clock_t start = clock();

			graph::al::EdgeByBatch process(graph_t, memory_size);
			bool update = true;
			while (update == true) {
				update = process.restructure();
			}

			std::vector<vertex_label_t > order;
			graph::al::dfs dfs_visitor;
			dfs_visitor.dfs_ts(process.T, order);

			std::reverse(order.begin(), order.end());

			std::ofstream out("result.txt", std::ios::out);
			for (size_t i = 0; i < order.size(); i++) {
				out << order[i] << " " << i << std::endl;
			}
			out.close();

			clock_t end = clock();
			std::cout << "time:" << (double)(end - start) / CLOCKS_PER_SEC << "s" << std::endl;
			std::cout << "io_read:" << io_read / (512 * 1024) << std::endl;
			std::cout << "io_write:" << io_write / (512 * 1024) << std::endl;
			std::cout << "io_num:" << io_num / (512 * 1024) << std::endl;
			return 0;
		}
		int ee(offline_graph graph_t, int memory_size)
		{


			//	preprocessing1(graph_t);

				//graph::preprocessing3(filename);

				//graph::preprocessing_dblp(filename);


			clock_t start = clock();

			graph::al::EdgeByBatch process(graph_t, memory_size);
			bool update = true;
			while (update == true) {
				update = process.edgebyedge();
			}

			std::vector<vertex_label_t > order;
			graph::al::dfs dfs_visitor;
			dfs_visitor.dfs_ts(process.T, order);

			std::reverse(order.begin(), order.end());

			std::ofstream out("result.txt", std::ios::out);
			for (size_t i = 0; i < order.size(); i++) {
				out << order[i] << " " << i << std::endl;
			}
			out.close();

			clock_t end = clock();
			std::cout << "time:" << (double)(end - start) / CLOCKS_PER_SEC << "s" << std::endl;
			std::cout << "io_read:" << io_read / (512 * 1024) << std::endl;
			std::cout << "io_write:" << io_write / (512 * 1024) << std::endl;
			std::cout << "io_num:" << io_num / (512 * 1024) << std::endl;
			return 0;
		}
		int dc(offline_graph graph_t, int memory_size) {



			clock_t start = clock();
			
			graph::al::DivideConquer process2(graph_t, memory_size);
			process2.DivideConquerDFS(process2.T, graph_t);
			//std::vector<vertex_label_t > order;
			/*graph::al::dfs dfs_visitor;
			dfs_visitor.dfs_ts(process2.T,order);

			std::reverse(order.begin(), order.end());

			std::ofstream out("result.txt", std::ios::out);
			for (size_t i = 0; i < order.size(); i++) {
#ifdef DEBUG
				io_num++;
				io_write++;
#endif // DEBUG
				out << order[i] << " " << i << std::endl;
			}
			out.close();
*/

			clock_t end = clock();
			std::cout << "time:" << (double)(end - start) / CLOCKS_PER_SEC << "s" << std::endl;
			std::cout << "io_read:" << io_read / (512 * 1024) << std::endl;
			std::cout << "io_write:" << io_write / (512 * 1024) << std::endl;
			std::cout << "io_num:" << io_num / (512 * 1024) << std::endl;
			return 0;
		}

		int nlts(offline_graph graph_t, int memory_size) {

			clock_t start = clock();

			graph::al::SemiTS process(graph_t, memory_size);
			process.naiveSemiTS();

			std::ofstream out("result.txt", std::ios::out);
			for (size_t i = 0; i <process.T.num_nodes; i++) {
				out << process.T.node_list[i]->get_label() << " " << process.T.node_list[i]->get_level() << std::endl;
			}
			out.close();

			clock_t end = clock();
			std::cout << "time:" << (double)(end - start) / CLOCKS_PER_SEC << "s" << std::endl;
			std::cout << "io_read:" << io_read / (512 * 1024) << std::endl;
			std::cout << "io_write:" << io_write / (512 * 1024) << std::endl;
			std::cout << "io_num:" << io_num / (512 * 1024) << std::endl;
			return 0;
		}

		int ilts(offline_graph graph_t, int memory_size) {

			clock_t start = clock();

			graph::al::SemiTS process(graph_t, memory_size);
			process.improveSemiTS();

			std::ofstream out("result.txt", std::ios::out);
			for (size_t i = 0; i < process.T.num_nodes; i++) {
				out << process.T.node_list[i]->get_label() << " " << process.T.node_list[i]->get_level() << std::endl;
			}
			out.close();

			clock_t end = clock();
			std::cout << "time:" << (double)(end - start) / CLOCKS_PER_SEC << "s" << std::endl;
			std::cout << "io_read:" << io_read / (512 * 1024) << std::endl;
			std::cout << "io_write:" << io_write / (512 * 1024) << std::endl;
			std::cout << "io_num:" << io_num / (512 * 1024) << std::endl;
			return 0;
		}
	
	int ilts_it(offline_graph graph_t, int memory_size) {

		clock_t start = clock();

		graph::al::SemiTS process(graph_t, memory_size);
		process.improveSemiTS_it();

		std::ofstream out("result.txt", std::ios::out);
		for (size_t i = 0; i < process.T.num_nodes; i++) {
			out << process.T.node_list[i]->get_label() << " " << process.T.node_list[i]->get_level() << std::endl;
		}
		out.close();

		clock_t end = clock();
		std::cout << "time:" << (double)(end - start) / CLOCKS_PER_SEC << "s" << std::endl;
		std::cout << "io_read:" << io_read / (512 * 1024) << std::endl;
		std::cout << "io_write:" << io_write / (512 * 1024) << std::endl;
		std::cout << "io_num:" << io_num / (512 * 1024) << std::endl;
		return 0;
	}


		int blts(offline_graph graph_t, int memory_size) {


			clock_t start = clock();

			graph::al::SemiTS process(graph_t, memory_size);
			process.batchSemiTS();

			std::ofstream out("result.txt", std::ios::out);
			for (size_t i = 0; i < process.T.num_nodes; i++) {
				out << process.T.node_list[i]->get_label() << " " << process.T.node_list[i]->get_level() << std::endl;
			}
			out.close();

			clock_t end = clock();
			std::cout << "time:" << (double)(end - start) / CLOCKS_PER_SEC << "s" << std::endl;
			std::cout << "io_read:" << io_read/(512*1024) << std::endl;
			std::cout << "io_write:" << io_write/(512*1024) << std::endl;
			std::cout << "io_num:" << io_num/(512*1024) << std::endl;
			return 0;
		}
	
	int it_blts(offline_graph graph_t, int memory_size) {


		clock_t start = clock();

		graph::al::SemiTS process(graph_t, memory_size);
		process.batchSemiTS_it();

		std::ofstream out("result.txt", std::ios::out);
		for (size_t i = 0; i < process.T.num_nodes; i++) {
			out << process.T.node_list[i]->get_label() << " " << process.T.node_list[i]->get_level() << std::endl;
		}
		out.close();

		clock_t end = clock();
		std::cout << "time:" << (double)(end - start) / CLOCKS_PER_SEC << "s" << std::endl;
		std::cout << "io_read:" << io_read / (512 * 1024) << std::endl;
		std::cout << "io_write:" << io_write / (512 * 1024) << std::endl;
		std::cout << "io_num:" << io_num / (512 * 1024) << std::endl;
		return 0;
	}
	
	int ju_blts(offline_graph graph_t, int memory_size) {


		clock_t start = clock();

		graph::al::SemiTS process(graph_t, memory_size);
		process.batchSemiTS_judge();

		std::ofstream out("result.txt", std::ios::out);
		for (size_t i = 0; i < process.T.num_nodes; i++) {
			out << process.T.node_list[i]->get_label() << " " << process.T.node_list[i]->get_level() << std::endl;
		}
		out.close();

		clock_t end = clock();
		std::cout << "time:" << (double)(end - start) / CLOCKS_PER_SEC << "s" << std::endl;
		std::cout << "io_read:" << io_read / (512 * 1024) << std::endl;
		std::cout << "io_write:" << io_write / (512 * 1024) << std::endl;
		std::cout << "io_num:" << io_num / (512 * 1024) << std::endl;
		return 0;
	}
	
	
}

