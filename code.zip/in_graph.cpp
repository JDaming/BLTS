#include <iostream>
#include <fstream>
#include  <string>
#include <algorithm>
#include <utility>
#include <map>

#include "in_graph.h"
#include "vertex.h"
#include "edge_iterator.h"
#include "offline_graph.h"
#include "types.h"


namespace graph {
	
	  void inner_graph::load(std::string& filename) {
		
		offline_graph o = offline_graph::load(filename);
		edge_iterator begin(filename.c_str()), end;
		o.num_edges = 0;
		//graph_type graph_t(o.get_num_nodes());
		T.vertex_list.resize(o.get_num_nodes()+1);
		T.num_vertices = o.get_num_nodes() + 1;
		for (size_t i = 0; i < T.vertex_list.size(); i++) {
			T.vertex_list[i] = new in_memory_vertex_descriptor();
			T.vertex_list[i]->label_ref() = i;
			T.vertex_list[i]->index_ref() = i;
		}
		edge current_edge;
		//vertex_type current_vertex;
	
		std::cout << "starting loading graph" << std::endl;
		for (edge_iterator itor = begin; itor != end; ++itor) {
			T.vertex_list[itor->first.get_label()]->successors_ref().push_back(T.vertex_list[itor->second.get_label()]);
			//status[itor->second.get_label()] = false;
			o.num_edges++;
		}
		
		std::cout << "num_vertices:" << T.num_vertices << std::endl;
		std::cout << "num_edges:" << o.num_edges << std::endl;
	}
	  
	void inner_graph::unregular_load(std::string& filename) {
		//offline_graph o = offline_graph::load(filename);
		edge_iterator begin(filename.c_str()), end;
		/*
		T.root.label_ref() = 0;
		T.root.index_ref() = 0;
		T.add_vertex(&T.root);
		*/
		//o.num_edges = 0;
		std ::map<vertex_label_t,int> hmap;
		std ::map<vertex_label_t, int>::iterator hm_itor1,hm_itor2;
		long int s, t;
		std::cout << "starting loading graph" << std::endl;
		for (edge_iterator itor = begin; itor != end; ++itor) {
			s = -1;
			t = -1;
			in_memory_vertex_descriptor* u = new in_memory_vertex_descriptor();
			in_memory_vertex_descriptor* v = new in_memory_vertex_descriptor();
			hm_itor1 = hmap.find(itor->first.get_label());
			hm_itor2 = hmap.find(itor->second.get_label());
			if (hm_itor1 != hmap.end())
				s = hm_itor1->second;
			else
			{
				u->index_ref() = T.num_vertices;
				s = T.num_vertices;
				u->label_ref() = itor->first.get_label();
				T.add_vertex(u);
				hmap.insert(std ::pair<vertex_label_t,int>(itor->first.get_label(), s));
			}
	
			if (hm_itor2 != hmap.end())
				t = hm_itor2->second;
			else
			{
				v->index_ref() = T.num_vertices;
				t = T.num_vertices;
				v->label_ref() = itor->second.get_label();
				T.add_vertex(v);
				hmap.insert(std::pair<vertex_label_t,int>(itor->second.get_label(), t));
			}
	

			
			
		
			std::cout << itor->first.get_label() << " " << itor->second.get_label() << std::endl;
			T.vertex_list[s]->successors_ref().push_back(T.vertex_list[t]);
		}

		//output regular graph
		std::cout << "starting outputing graph" << std::endl;
		std::ofstream outfile("dblp_regular", std::ios::out);
		int edges = 0;
		for (size_t i = 0; i < T.num_vertices; i++) {
			for (size_t j = 0; j < T.vertex_list[i]->successors_ref().size(); j++) {
				std::stringstream ss;
				ss << i+1 << " " << T.vertex_list[i]->successors_ref()[j]->get_index()+1 << std::endl;
				edges++;
				outfile << ss.str();
			}
		}
		outfile.close();
		std::cout << "edges:" << edges << std::endl;

	}
	void inner_graph::turn_to_dag() {

		std::vector<color> status;
		status.assign(T.num_vertices, white);
		//std::vector<int > dtime(T.num_vertices,-1);
		//std::vector<int > ftime(T.num_vertices,-1);
		int t = 0;
		std::cout << "starting dfs...." << std::endl;
		for (size_t i = 0; i < T.num_vertices; i++) {
			if (status[i] == white)
				dfs_node(i, status);
		}
		
		std::vector<color>().swap(status);
	}

	void inner_graph::turn_to_dag2() {

		std::vector<color> status;
		status.assign(T.num_vertices, white);
		//std::vector<int > dtime(T.num_vertices,-1);
		//std::vector<int > ftime(T.num_vertices,-1);
		int t = 0;
		std::cout << "starting dfs...." << std::endl;
		for (size_t i = 0; i < T.num_vertices; i++) {
			if (status[i] == white)
				dfs_node2(i, status);
		}

		std::vector<color>().swap(status);
	}
	void inner_graph::dfs_node(vertex_label_t u,std::vector<color>& status) {
		//dtime[u] = t++;
		status[u] = gray;
		for (size_t i = 0; i < T.vertex_list[u]->successors_ref().size(); i++) {
			int pos = T.vertex_list[u]->successors_ref()[i]->get_label();
			switch (status[pos]) {
			case white:
				std::cout << "in:" << u << " " << pos << std::endl;
				dfs_node(pos, status);
				break;
			case gray:
				std::cout << "back-edge:" << u << " " << T.vertex_list[u]->successors_ref()[i]->get_label()<<std::endl;
				T.vertex_list[u]->successors_ref().erase(T.vertex_list[u]->successors_ref().begin() + i);
				i--;
				
				break;
			case black:
				break;
			}
		}

		status[u] = black;
		//ftime[u] = t++;
	}
	void inner_graph::dfs_node2(vertex_label_t u, std::vector<color>& status) {
		//dtime[u] = t++;
		status[u] = gray;
		for (size_t i = 0; i < T.vertex_list[u]->successors_ref().size(); i++) {
			int pos = T.vertex_list[u]->successors_ref()[i]->get_label();
			switch (status[pos]) {
			case white:
				std::cout << "in:" << u << " " << pos << std::endl;
				dfs_node2(pos, status);
				break;
			case gray:
				std::cout << "back-edge:" << u << " " << T.vertex_list[u]->successors_ref()[i]->get_label() << std::endl;
				T.vertex_list[u]->successors_ref().erase(T.vertex_list[u]->successors_ref().begin() + i);
				bool flag;
				flag = true;
				if (u != pos) {
					for (size_t j = 0; j < T.vertex_list[pos]->successors_ref().size(); j++)
						if (T.vertex_list[pos]->successors_ref()[j]->get_label() == T.vertex_list[u]->get_label()) {
							flag = false;
							break;
						}
							
				}
				else {
					flag = false;
				}
				if(flag)
					T.vertex_list[pos]->successors_ref().push_back(T.vertex_list[u]);
				i--;
				
				break;
			case black:
				break;
			}
		}

		status[u] = black;
		//ftime[u] = t++;
	}
	void inner_graph::output(std::string filename) {
		std::ofstream outfile(filename.c_str(), std::ios::out);
		int edges = 0;
		for (size_t i = 0; i < T.num_vertices; i++) {
			for (size_t j = 0; j < T.vertex_list[i]->successors_ref().size(); j++) {
				std::stringstream ss;
				ss << i << " " << T.vertex_list[i]->successors_ref()[j]->get_label() << std::endl;
				edges++;
				outfile << ss.str();
			}
		}
		outfile.close();
		std::cout << "edges:" << edges << std::endl;
	}
}