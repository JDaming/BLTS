#include "offline_graph.h"

#include <sstream>
#include <iostream>
#include <string>
#include <boost/shared_ptr.hpp>

namespace graph {
	offline_graph::offline_graph():n(0),num_edges(0){}
	offline_graph::~offline_graph(){}

	offline_graph offline_graph::load(const std::string& basename) {
		
		offline_graph result;

		long int tmp1;
		long int tmp2;

		result.filename = basename;

		
		std::ifstream file(basename.c_str());
		//file.open();
		std::string line;

		if (!file.is_open())
			std::cout << '1';

		while (getline(file, line) ) {
			std::istringstream iss(line);
			iss >> tmp1;
			iss >> tmp2;
			result.n = (result.n > tmp1) ? result.n : tmp1;
			result.n = (result.n > tmp2) ? result.n : tmp2;
	
			result.num_edges++;
		}
		file.close();

		return result;
	}

	


	std::pair<vertex_iterator, vertex_iterator> offline_graph::get_vertex_iterator(int from)const {
		if (from != 0) {
			std::cerr<< "from is not implemented.\n";
		}
		return std::make_pair(vertex_iterator(filename.c_str()),
			vertex_iterator());
	}

	std::pair<edge_iterator, edge_iterator> offline_graph::get_edge_iterator() const {
		edge_iterator begin(filename.c_str());
		edge_iterator end;

		return std::make_pair(begin, end);
	}
}