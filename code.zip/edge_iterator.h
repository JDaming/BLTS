#pragma once

#include <utility>
#include <sstream>
#include <boost/iterator/iterator_facade.hpp>

#include "vertex_iterator.h"
#include "vertex.h"
#include "edge.h"

#include <iostream>


namespace graph {
	class edge_iterator : public boost::iterator_facade<edge_iterator, edge const, boost::forward_traversal_tag> {
	private:
		edge current_edge;

		int current_successor_index;

		vertex_iterator current_vertex;
		vertex_iterator last_vertex;

		bool is_end_marker;

		unsigned long num_vertices;

		void fetch_next_edge();
	public:
		edge_iterator();
		explicit edge_iterator(const char* filename);
		edge_iterator(const edge_iterator& rhs);
		
		virtual ~edge_iterator();
		
		edge_iterator& operator = (const edge_iterator& rhs);

	private:
		friend class boost::iterator_core_access;
		
		void increment() {
			fetch_next_edge();
		}

		bool equal(const edge_iterator& other)const {
			return (this->is_end_marker && other.is_end_marker) || (current_edge == other.current_edge && !this->is_end_marker && !other.is_end_marker);
		}

		const edge& dereference() const {
			return current_edge;
		}

	};

	
}