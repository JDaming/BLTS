#include <queue>
#include <string>
#include <sstream>
#include <fstream>
#include <map>
#include <boost/shared_ptr.hpp>

#include "DivideConquer.h"
#include "types.h"
#include "iocount.h"
#include "lowest_common_ancestor.h"
#include "EdgeByBatch.h"

namespace graph {
	namespace al {
		DivideConquer::DivideConquer()
		{
		}
		DivideConquer::DivideConquer(offline_graph o, int memory_size)			
		{
			window_size = memory_size;
			filename = o.filename;
			//edge_memory.resize(window_size / sizeof(edge));
			T.generate(o);
		}
		DivideConquer::DivideConquer(int memory_size, spanning_tree& T)			
		{
			window_size = memory_size;
			//edge_memory.resize(window_size / sizeof(edge));


		}
		void DivideConquer::DivideConquerDFS(spanning_tree& tree, graph_type& g)
		{
#ifdef DEBUG
			std::cout << "starting DivideConquerDFS" << std::endl;
#endif
			Divide  divide(tree, g.filename, window_size);
			EdgeByBatch process(tree, window_size, g.filename);
#ifdef DEBUG
			std::cout <<"number of edges:"<< g.num_edges << std::endl;
#endif
			if (g.num_edges < window_size) {
				process.restructure(divide.T);
				return;
			}

			dividable = false;
			while (dividable == false) {

#ifdef DEBUG
				std::cout << "starting restructure" << std::endl;
#endif // DEBUG

				
				bool update = process.restructure(divide.T);
				if (update == false) {
					return ;
				}
#ifdef DEBUG
				std::cout << "starting divide" << std::endl;
#endif // DEBUG

				
				divide.divide_TD();
#ifdef DEBUG

				std::cout << "size:" << divide.subgraphs.size() << std::endl;
#endif // DEBUG
				
				
				if (divide.subgraphs.size() > 2)
					dividable = true;	
					
			}
			
			for (size_t i = 1; i < divide.subgraphs.size(); i++) {
#ifdef DEBUG
				std::cout << "handling subgraph:" << i << std::endl;
#endif // DEBUG

				
				DivideConquerDFS(divide.subtrees[i], divide.subgraphs[i]);
			
			
			
			}
			spanning_tree final_tree;
			divide.merge(final_tree);
			tree = final_tree;
		
		}


		
			Divide::Divide(spanning_tree& tree, std::string file, int m)
			{
				T = tree;
				filename = file;
				memory = m;
				scc_num = -1;
			}

			
			void Divide::divide_TD()
			{
			
				int num_vertices = T.num_vertices;
				//initial
			
				s_graph.num_vertices = 0;
				s_graph.vertex_list.clear();
				s_graph.root.successors_ref().clear();

				subgraphs.clear();
				subtrees.clear();

				////

				edge_iterator  begin(filename.c_str()), end;


				std::cout << "generate s-graph" << std::endl;
			
				spanning_tree cut_tree;

				s_graph_type s_graph_trans;

				s_graph.root.label_ref() = T.root.get_label();
				s_graph.root.index_ref() = 0;
				s_graph.add_vertex(&(s_graph.root));

				s_graph_trans.root.label_ref() = T.root.get_label();
				s_graph_trans.root.index_ref() = 0;
				s_graph_trans.add_vertex(&(s_graph_trans.root));

				cut_tree.root.label_ref() = T.root.get_label();
				cut_tree.root.index_ref() = 0;
				cut_tree.add_vertex(&(cut_tree.root));
			
				std::queue<in_memory_vertex_descriptor* > q;
				
				for (size_t i = 0; i < T.root.successors_ref().size(); i++) {
					q.push(T.root.successors_ref()[i]);

					in_memory_vertex_descriptor* u = new in_memory_vertex_descriptor();
					in_memory_vertex_descriptor* v = new in_memory_vertex_descriptor();
					in_memory_vertex_descriptor* w = new in_memory_vertex_descriptor();

					u->label_ref() = T.root.successors_ref()[i]->get_label();
					u->index_ref() = s_graph.num_vertices;

					v->label_ref() = T.root.successors_ref()[i]->get_label();
					v->index_ref() = s_graph_trans.num_vertices;

					w->label_ref() = T.root.successors_ref()[i]->get_label();
					w->index_ref() = cut_tree.num_vertices;

					cut_tree.add_vertex(w);
					cut_tree.root.successors_ref().push_back(cut_tree.vertex_list[cut_tree.num_vertices - 1]);

					s_graph.add_vertex(u);
					s_graph.root.successors_ref().push_back(s_graph.vertex_list[s_graph.num_vertices - 1]);
					//s_graph.num_vertices++;
				

					v->successors_ref().push_back(&s_graph_trans.root);
					s_graph_trans.add_vertex(v);
				}



			//vertex_label_t r = T.s.get_label();
				int index_s = 1;
			//int index_f = 1;
				while (!q.empty()) {
					in_memory_vertex_descriptor* pos = q.front();
					q.pop();
					std::vector<in_memory_vertex_descriptor* > outedges = pos->successors_ref();
					int outdegree = outedges.size();
					if ((s_graph.num_vertices + outdegree-1) < std ::sqrt(memory)) { //s_graph size
						for (size_t i = 0; i < outdegree; i++) {


							in_memory_vertex_descriptor* u = new in_memory_vertex_descriptor();
							in_memory_vertex_descriptor* v = new in_memory_vertex_descriptor();
							in_memory_vertex_descriptor* w = new in_memory_vertex_descriptor();

							u->label_ref() = outedges[i]->get_label();
							u->index_ref() = s_graph.num_vertices;

							v->label_ref() = outedges[i]->get_label();
							v->index_ref() = s_graph_trans.num_vertices;

							w->label_ref() = outedges[i]->get_label();
							w->index_ref() = cut_tree.num_vertices;

							cut_tree.add_vertex(w);
							cut_tree.vertex_list[index_s]->successors_ref().push_back(cut_tree.vertex_list[cut_tree.num_vertices - 1]);
							cut_tree.vertex_list[cut_tree.num_vertices - 1]->parent_ref() = index_s;
							
							s_graph.add_vertex(u);
							s_graph.vertex_list[index_s]->successors_ref().push_back(s_graph.vertex_list[s_graph.num_vertices - 1]);
							//s_graph.num_vertices++;
							q.push(outedges[i]);

							v->successors_ref().push_back(s_graph_trans.vertex_list[index_s]);
							s_graph_trans.add_vertex(v);
						//s_graph_trans.num_vertices++;

						}
						index_s++;
				}
				else {
					break;
				}
			}

			dfs dfs_visitor(num_vertices);
			lca LCA(num_vertices, T);
			//LCA.precompute_lca(dfs_visitor);
			LCA.precompute_lca(dfs_visitor);


			for (edge_iterator itor = begin; itor != end; ++itor) {

				
				//std::cout << "current edge:" << itor->first << " " << itor->second << std::endl;

				int s_index = is_in_graph(itor->first, T);

				int e_index = is_in_graph(itor->second, T);
				//std::cout << s_index << " " << e_index<<std::endl;
				int w = LCA.lca_of_vertices(s_index, e_index, dfs_visitor);
				
				
				if (dfs_visitor.is_cross_edge(s_index, e_index) && is_nonleaf_node(T.vertex_list[w]->get_label(), cut_tree)) {
					edge_type e = s_edge(*itor, w, dfs_visitor);
					
					if (is_in_graph(T.vertex_list[w]->successors_ref()[e.first]->get_label(), cut_tree) != -1 && is_in_graph(T.vertex_list[w]->successors_ref()[e.second]->get_label(), cut_tree) != -1) {
						int index = is_in_graph(T.vertex_list[w]->get_label(), cut_tree);
						int tmp_pos1 = s_graph.vertex_list[index]->successors_ref()[e.first]->get_index();
						int tmp_pos2 = s_graph.vertex_list[index]->successors_ref()[e.second]->get_index();
						bool in_flag = false;
						for (size_t i = 0; i < s_graph.vertex_list[tmp_pos1]->successors_ref().size(); i++) {
							if (s_graph.vertex_list[tmp_pos1]->successors_ref()[i]->get_label() == s_graph.vertex_list[tmp_pos2]->get_label()) {
								in_flag = true;
								break;
							}
						}
						if (!in_flag) {
							s_graph.vertex_list[tmp_pos1]->successors_ref().push_back(s_graph.vertex_list[tmp_pos2]);
							s_graph_trans.vertex_list[tmp_pos2]->successors_ref().push_back(s_graph_trans.vertex_list[tmp_pos1]);
						}
						
					}
					//boost::add_edge(e.first, e.second, s_graph);


					//s_graph.vertex_list[e.first].successors_ref().push_back(e.second);
					//s_graph_trans.vertex_list[e.second].successors_ref().push_back(e.first);


				}
			}


			//if s-graph is not DAG
			std::cout << "if s-graph is not DAG" << std::endl;
			
			bool flag = false;

			std::vector<vertex_label_t> order;
			std::vector<vertex_label_t > component;
			std::vector<std::vector<vertex_label_t> >components;
			std::vector<color > status;

			status.assign(s_graph.num_vertices, white);


			for (size_t i = 0; i < s_graph.num_vertices; i++) {
				if (status[i] == white)
					s_graph.dfs_node(i, order, status, flag);
			}

			status.assign(s_graph.num_vertices, white);
 			if (flag) {
				for (size_t i = 0; i < s_graph_trans.num_vertices; i++) {
					int index = order[s_graph_trans.num_vertices - 1 - i];
					if (status[index] == white) {
						s_graph_trans.scc_dfs_node(index, component, status);
						components.push_back(component);
						component.clear();
					}
				}

				// for all scc in s-graph, contraction operation;
				for (size_t i = 0; i < components.size(); i++) {
					if (components[i].size() > 1) {
						in_memory_vertex_descriptor* node1 = new in_memory_vertex_descriptor();
						in_memory_vertex_descriptor* node2 = new in_memory_vertex_descriptor();
						node1->label_ref() = scc_num;
						node2->label_ref() = scc_num;
						scc_num--;
						bool scc_flag = false;
						for (size_t j = 0; j < components[i].size(); j++) {
							//modify T
							
							//modify out-edges of each vertex in scc
							//for (size_t k = 0; k < T.vertex_list[components[i][j]]->successors_ref().size(); k++)
							//	node1->successors_ref().push_back(T.vertex_list[components[i][j]]->successors_ref()[k]);
	
							node1->successors_ref().push_back(T.vertex_list[components[i][j]]);
							
							//modify in-edges of each vertex in scc
							for (size_t k = 0; k < T.num_vertices; k++) {
								for (size_t p = 0; p < T.vertex_list[k]->successors_ref().size(); p++) {
									if (T.vertex_list[k]->successors_ref()[p]->get_label() == components[i][j]) {
										if (!scc_flag) {
											T.vertex_list[k]->successors_ref()[p] = node1;	
											node1->parent_ref() = k;
											scc_flag = true;
										}
										else {
											T.vertex_list[k]->successors_ref().erase(T.vertex_list[k]->successors_ref().begin() + p);
											p--;
										}
									}

								}
							}
							
							


							//modify s_graph

							for (size_t k = 0; k < s_graph.num_vertices; k++) {
								int u = s_graph.vertex_list[k]->get_label();
								//handle in edges 
								for (size_t p = 0; p < s_graph.vertex_list[k]->successors_ref().size(); p++) {
									if (s_graph.vertex_list[k]->successors_ref()[p]->get_label() == components[i][j]) {
										s_graph.vertex_list[k]->successors_ref()[p] = node2;
									}
								}
								if (u == components[i][j]) {
									for (size_t p = 0; p < s_graph.vertex_list[k]->successors_ref().size(); p++) {
										if (s_graph.vertex_list[k]->successors_ref()[p]->get_label() != -1) {
											bool tmp_flag = false;
											for (size_t l = 0; l < components[i].size(); l++)
												if (s_graph.vertex_list[k]->successors_ref()[p]->get_label() == components[i][l]) {
													tmp_flag = true;
													continue;
												}

											if (!tmp_flag)
												node2->successors_ref().push_back(s_graph.vertex_list[k]->successors_ref()[p]);
										}


									}
									//remove node in scc
									s_graph.vertex_list.erase(s_graph.vertex_list.begin() + k);
									
									s_graph.num_vertices--;
									k--;
								}
							}

						}
						node1->index_ref() = T.num_vertices;
						T.add_vertex(node1);
						node2->index_ref() = s_graph.num_vertices;
						s_graph.add_vertex(node2);
					}
				}

				//end handle scc
				std::cout << "end handle scc" << std::endl;
			}

			// divide	
			std::cout << "divide" << std::endl;
			spanning_tree T0;
			T0.root = T.root;
			T0.root.successors_ref().clear();
			T0.add_vertex(&(T0.root));
			std::queue<in_memory_vertex_descriptor* > qlist;
			qlist.push(&(T.root));
			std::vector<int> node_position(T.num_vertices, 0);
		
				
				
			while (!qlist.empty()) {
				in_memory_vertex_descriptor* u = qlist.front();
				qlist.pop();
				if (u->get_label() >= 0) {
					int pos1 = is_in_graph(u->get_label(), T0);
/*
					if (pos1 == -1) {
						in_memory_vertex_descriptor* node = new in_memory_vertex_descriptor();
						node->label_ref() = u->get_label();
						node->index_ref() = T0.num_vertices;
						T0.add_vertex(node);
						pos1 = T0.num_vertices - 1;
					}*/

					for (size_t i = 0; i < u->successors_ref().size(); i++) {
						if ((is_in_graph(u->successors_ref()[i]->get_label(), cut_tree) != -1) || u->successors_ref()[i]->get_label() < 0) {
							int pos2 = is_in_graph(u->successors_ref()[i]->get_label(), T0);
							if (pos2 == -1) {
								in_memory_vertex_descriptor* node2 = new in_memory_vertex_descriptor();
								node2->label_ref() = u->successors_ref()[i]->get_label();
								node2->index_ref() = T0.num_vertices;
								T0.add_vertex(node2);
								pos2 = T0.num_vertices - 1;
							}

							qlist.push(u->successors_ref()[i]);
							//node->successors_ref().push_back(T0.vertex_list[num_vertices-1]);
							T0.vertex_list[pos1]->successors_ref().push_back(T0.vertex_list[pos2]);
						}

					}
				}
			}
			//T0.root = *(T0.vertex_list[0]);
			for (size_t i = 0; i < s_graph.num_vertices; i++) {
				if (is_in_graph(s_graph.vertex_list[i]->get_label(), T0) == -1) {
					s_graph.vertex_list.erase(s_graph.vertex_list.begin() + i);
					s_graph.num_vertices--;
					i--;
					continue;
				}

				for (size_t j = 0; j < s_graph.vertex_list[i]->successors_ref().size(); j++) {
					if (is_in_graph(s_graph.vertex_list[i]->successors_ref()[j]->get_label(), T0) == -1) {
						s_graph.vertex_list[i]->successors_ref().erase(s_graph.vertex_list[i]->successors_ref().begin() + j);
					}
				}

			}
			for (size_t i = 0; i < s_graph.num_vertices; i++) {
				s_graph.vertex_list[i]->index_ref() = i;
			}
			//divide by the leaf node of root of T0;
			std::cout << "generate subtrees" << std::endl;
				
			//generate subtrees
			std::vector<in_memory_vertex_descriptor*> leafs;

			leaf_node(T0, leafs, T);
			subtrees.push_back(T0);

			for (size_t i = 0; i < leafs.size(); i++) {
				in_memory_vertex_descriptor* r = new in_memory_vertex_descriptor();
				spanning_tree tmp_tree;
				std::tr1::unordered_map<vertex_label_t, int>::iterator hm_itor;
				hm_itor = T.vertex_map.find(leafs[i]->get_label());
				*r = *(T.vertex_list[hm_itor->second]);
				tmp_tree.root = *r;
				/*
				if (leafs[i]->get_label() < 0) { //virtual nodes
					for (size_t j = 0; j < T.num_vertices; j++) {
						if (T.vertex_list[j]->get_label() == leafs[i]->get_label()) {
							*r = *(T.vertex_list[j]);
							tmp_tree.root = *r;

							//tmp_tree.add_vertex(r);
						}
					}
				}
				else {
					*r = *(T.vertex_list[leafs[i]->get_index()]);
					tmp_tree.root = *r;

					//tmp_tree.add_vertex(r);
				}
				
				
*/		
				subtrees.push_back(tmp_tree);


			}
			std::tr1::unordered_map<vertex_label_t, int>::iterator hm_itor;
			
			for (size_t i = 1; i < subtrees.size(); i++) {

				qlist.push(&(subtrees[i].root));

				in_memory_vertex_descriptor* u = new in_memory_vertex_descriptor();
				
				u->label_ref() = qlist.front()->get_label();
				u->index_ref() = subtrees[i].num_vertices;
				hm_itor = T.vertex_map.find(u->label_ref());
				node_position[hm_itor->second] = i;
				subtrees[i].add_vertex(u);

				int pos = 0;
				while (!qlist.empty()) {

					for (size_t k = 0; k < qlist.front()->successors_ref().size(); k++) {
						qlist.push(qlist.front()->successors_ref()[k]);

						in_memory_vertex_descriptor* v = new in_memory_vertex_descriptor();
						v->label_ref() = qlist.front()->successors_ref()[k]->get_label();

						v->index_ref() = subtrees[i].num_vertices;
						subtrees[i].vertex_list[pos]->successors_ref().push_back(v);
						subtrees[i].add_vertex(v);
						hm_itor = T.vertex_map.find(v->label_ref());
						node_position[hm_itor->second] = i;
						

					}

					qlist.pop();
					pos++;

				}
				subtrees[i].root = *(subtrees[i].vertex_list[0]);
			}
				subtrees[0].vertex_list[0] = &subtrees[0].root;

			//generate subgraph for each subtree;
			
			std::vector <FILE* >outfiles;	
				
			for (size_t i = 0; i < subtrees.size(); i++) {
				
				std::stringstream ss;
				//std::string subfilename = filename + std::to_string(i);



				ss << filename <<"_"<<i;
				graph_type tmp_g;
				tmp_g.filename = ss.str();
				tmp_g.n = subtrees[i].num_vertices;
				tmp_g.num_edges = 0;
				subgraphs.push_back(tmp_g);
				//std::cout << "Ouputing subgraph file:" << ss.str() << std::endl;
				FILE* out = fopen(ss.str().c_str(), "w");

				//std::ofstream o(ss.str().c_str(), std::ios::out | std::ios::app);
				outfiles.push_back(out);
			}
			
				char** wt_buf = new char*[outfiles.size()];
				for (size_t i =  0; i < outfiles.size(); i++)
					wt_buf[i] = new char[BUFSIZ];
				int* buf_offset = new int[outfiles.size()];
				for (size_t i = 0; i < outfiles.size(); i++)
					buf_offset[i] = 0;
				
				char *line = new char[BUFSIZ];
				int line_offset = 0;
				
				size_t len = BUFSIZ;
				ssize_t nread;
				
				
				FILE* rd_fd = fopen(filename.c_str(),"r");
				
				while (getline(&line, &len, rd_fd) != -1)
				{
#ifdef DEBUG
					io_num++;
					io_read++;
#endif // DEBUG
					nread = strlen(line);
					
					std::istringstream iss(line);
					edge tmp;
					
					iss >> tmp.first.label_ref();
					iss >> tmp.second.label_ref();
					
					std::tr1::unordered_map<vertex_label_t, int>::iterator hm_itor1, hm_itor2;
					hm_itor1 = T.vertex_map.find(tmp.first.label_ref());
					hm_itor2 = T.vertex_map.find(tmp.second.label_ref());
					int number = node_position[hm_itor1->second];
					if (number == node_position[hm_itor2->second] && number!= -1)
					{
						subgraphs[number].num_edges++;
						if (buf_offset[number] + nread < BUFSIZ)
						{
							memcpy(wt_buf[number] + buf_offset[number], line, nread);
							buf_offset[number] += nread;
#ifdef DEBUG
							io_num++;
							io_write++;
							
#endif // DEBUG
						}
						else
						{
							memcpy(wt_buf[number] + buf_offset[number], line, BUFSIZ - buf_offset[number]);
							line_offset = BUFSIZ - buf_offset[number];
							buf_offset[number] = nread - line_offset;
							//fputs(wt_buf, wt_fd);
#ifdef DEBUG
							io_num++;
							io_write++;
#endif // DEBUG
							fwrite(wt_buf[number], sizeof(char), BUFSIZ, outfiles[number]);
							memcpy(wt_buf[number], line + line_offset, nread - line_offset);
							
							line_offset = 0;
						}					
					}
					
				}
				for (size_t i = 0; i < outfiles.size(); i++) {
					fwrite(wt_buf[i], sizeof(char), buf_offset[i], outfiles[i]);
					fclose(outfiles[i]);
				}

				
				delete[]line;
				for(size_t i = 0; i<outfiles.size(); i++)
					delete[]wt_buf[i];
				delete[] buf_offset;
			

	}

			

			

			edge_type Divide::s_edge(edge_type e, vertex_label_t p, dfs& dfs_visitor) {
				vertex_label_t u = pushup(e.first, p, dfs_visitor);
				vertex_label_t v = pushup(e.second, p,dfs_visitor);
				return std::make_pair(u, v);
			
			}

		vertex_label_t Divide::pushup(vertex_label_t u, vertex_label_t p, dfs& dfs_visitor) {
				//boost::graph_traits<graph_type>::out_edge_iterator ei, ei_end;
				std::vector<in_memory_vertex_descriptor* > outedges = T.vertex_list[p]->successors_ref();
				int out_degree = outedges.size();
				for (size_t i = 0; i < out_degree; i++) {
					in_memory_vertex_descriptor* tmp = outedges[i];
					if (tmp->get_label() == u || is_ancestor(tmp, u,dfs_visitor) )
						return i;
				}
				return -1;
			} 

		bool Divide::is_ancestor(in_memory_vertex_descriptor * & u, vertex_label_t v, dfs& dfs_visitor) {
				
				in_memory_vertex_descriptor * t;
				std::tr1::unordered_map<vertex_label_t, int>::iterator hm_itor;
				hm_itor = T.vertex_map.find(v);
				if (hm_itor == T.vertex_map.end())
					return false;
				
				if (dfs_visitor.dtime[u->get_index()] < dfs_visitor.dtime[hm_itor->second] && dfs_visitor.ftime[u->get_index()] < dfs_visitor.ftime[hm_itor->second])
				{
					return true;
				}
			return false;
			}

			int Divide::is_in_graph(vertex_label_t u, spanning_tree& t)
			{
				std::tr1::unordered_map<vertex_label_t, int>::iterator hm_itor;
				hm_itor = t.vertex_map.find(u);
				if (hm_itor == t.vertex_map.end())
					return -1;
				else
					return hm_itor->second;
			}

			bool Divide::is_nonleaf_node(vertex_label_t u, spanning_tree& t)
			{
				std::tr1::unordered_map<vertex_label_t, int>::iterator hm_itor;
				hm_itor = t.vertex_map.find(u);
				if (hm_itor != t.vertex_map.end() && t.vertex_list[hm_itor->second]->successors_ref().size() != 0)
					return true;
				else
					return false;
			
			}

			void graph::al::Divide::leaf_node(spanning_tree tree, std::vector<in_memory_vertex_descriptor*>& leafs, spanning_tree & T)
			{
				
				for (size_t i = 0; i < tree.num_vertices; i++)
		
					if (tree.vertex_list[i]->successors_ref().size() == 0 && T.vertex_list[T.vertex_map.find(tree.vertex_list[i]->get_label())->second]->successors_ref().size() != 0)
						leafs.push_back(tree.vertex_list[i]);
			
			}

			int Divide::in_which_subgraph(vertex_label_t u)
			{
				for (size_t i = 0; i < subtrees.size(); i++) {
					if (is_in_graph(u, subtrees[i]) >= 0)
						return i;
				}
				return -1;
			}

		
		
			void Divide::merge(spanning_tree & tree)
			{
				
				//spanning_tree tree;
				//tree.root = subtrees[0].root;
				//tree.root.successors_ref().clear();
				tree.root.label_ref() = subtrees[0].root.get_label();
				tree.root.index_ref() = 0;
				tree.add_vertex(&(tree.root));

				std::vector <vertex_label_t > order;
				std::vector<color > status;
				status.assign(s_graph.num_vertices, white);
				
				std::tr1::unordered_map<vertex_label_t, int> index;
				
				
				bool flag = false;
				for (size_t i = 0; i < s_graph.num_vertices; i++) {
					if (status[i] == white)
						s_graph.dfs_node(i, order, status, index);
				}
				//reorder the tree by reverse topological order of s_graph
		

				//construct tree;
				
				
				//		hm_itor = .vertex_map.find(s_graph.vertex_list[order[i]]->get_label());
				
				std::queue<in_memory_vertex_descriptor* > qlist;

				qlist.push(&subtrees[0].root);
				int pos = 0;
				std::tr1::unordered_map<vertex_label_t, int>::iterator hm_itor;
				while (!qlist.empty()) {
					in_memory_vertex_descriptor* u = qlist.front();
					qlist.pop();
					//int sub_successor = 0;
					std::vector<int> order_list;
					order_list.resize(u->successors_ref().size());
					for (size_t i = 0; i < u->successors_ref().size(); i++)
					{
						
						hm_itor = index.find(u->successors_ref()[i]->get_label());
						if (hm_itor != index.end())
						{
							order_list[i] = hm_itor->second;
						}
					}
					std::sort(order_list.begin(), order_list.end());
					for (size_t j = 0; j < order_list.size(); j++)
					{
						in_memory_vertex_descriptor* v = new in_memory_vertex_descriptor();
						v->label_ref() = s_graph.vertex_list[order[order_list[j]]]->get_label();
						v->index_ref() = tree.num_vertices;
						tree.vertex_list[pos]->successors_ref().push_back(v);
						tree.add_vertex(v);
						hm_itor  = subtrees[0].vertex_map.find(v->label_ref());
						if (hm_itor != subtrees[0].vertex_map.end())
						{
							qlist.push(subtrees[0].vertex_list[hm_itor->second]);
						}
						
					}
					
					pos++;
				}
				for (size_t i = 0; i < tree.num_vertices; i++) {
					tree.vertex_list[i]->index_ref() = i;
				}
				//combine tree;

				for(size_t i = 1 ; i < subtrees.size() ; i++) {
					
					hm_itor = tree.vertex_map.find(subtrees[i].root.get_label());
					if (hm_itor != tree.vertex_map.end()) {
						tree.vertex_list[hm_itor->second] = subtrees[i].vertex_list[0];
					}
					/*for (size_t j = 0; j < tree.num_vertices; j++) {
						if (subtrees[i].root.get_label() == tree.vertex_list[j]->get_label()) {
							tree.vertex_list[j] = subtrees[i].vertex_list[0];
							//tree.num_vertices += subtrees[i].num_vertices;
						}
					}
					}*/

					for (size_t k = 1; k < subtrees[i].num_vertices; k++) {
						tree.add_vertex(subtrees[i].vertex_list[k]);
					}
				}

				// remove virtual node in tree;
				flag = true;
				for (size_t i = 0; i < tree.num_vertices; i++) {
					if (tree.vertex_list[i]->get_label() < 0) {
						//find parent of virtual node
						for(size_t j = 0 ; j < tree.num_vertices && j != i ; j++) {
							for (size_t k = 0; k < tree.vertex_list[j]->successors_ref().size(); k++) {
								if (tree.vertex_list[j]->successors_ref()[k]->get_label() == tree.vertex_list[i]->get_label()) {
									tree.vertex_list[j]->successors_ref().erase(tree.vertex_list[j]->successors_ref().begin() + k);
									for (size_t p = 0; p < tree.vertex_list[i]->successors_ref().size(); p++) {
										tree.vertex_list[j]->successors_ref().push_back(tree.vertex_list[i]->successors_ref()[p]);
									}
								}
							}
						}
						tree.vertex_list.erase(tree.vertex_list.begin() + i);
						i--;
						tree.num_vertices--;

					}
				}
			
			

				
			
			}

		}
	}




