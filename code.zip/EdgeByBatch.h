#pragma once
#include <iostream>
#include <utility>
#include <algorithm>
#include <vector>

#include <boost/shared_ptr.hpp>
#include <boost/graph/depth_first_search.hpp>
#include <boost/graph/adjacency_list.hpp>

//#include <boost/graph/graph_traits.hpp>
#include "spanning_tree.h"
#include "offline_graph.h"
#include "edge.h"


namespace graph {
	namespace al {
		


			class EdgeByBatch {
			private:
				std::string filename;
				//offline_graph g;
				const static int STD_BUFFER_SIZE = 1024 * 1024;
				int window_size;

				//boost::shared_ptr<std::vector<edge> > edge_memory_ptr;
				//std::vector<edge>& edge_memory;

				


				//bool is_forward_cross_edge(edge e);
			public:
				spanning_tree T;
				EdgeByBatch();
				EdgeByBatch(spanning_tree& tree, int memory_size, std::string file);
				EdgeByBatch(offline_graph g, int memory_size);
				bool restructure(spanning_tree & tree);
				bool restructure();

				bool edgebyedge();
				//int is_in_graph(vertex_label_t u, in_memory_vertex_descriptor* root);

			};


		
		
	}
}