#pragma once
#include <iostream>
#include <vector>


#include "types.h"
#include "dfs.h"
#include "spanning_tree.h"
namespace graph {
	namespace al {
		class lca {
		private:
			
			//typedef boost::adjacency_list<boost::vecS, boost::vecS, boost::directedS > graph_type;
			typedef std::pair<vertex_label_t, vertex_label_t> edge_type;
			typedef spanning_tree graph_type;

			int num_vertices;
			int block_size, block_cnt;
	
			std::vector<int> euler_tour;
			std::vector<int> log_2;
			std::vector<std::vector<std::vector<int> > > blocks;
			std::vector<std::vector<int> > st;
			std::vector<int> block_mask;
			
			graph_type g;
			
			
			int min_by_h(int i, int j, dfs& dfs_visitor) {
				return dfs_visitor.height[euler_tour[i]] < dfs_visitor.height[euler_tour[j]] ? i : j;
			}

			


			int lca_in_block(int b, int l, int r) {
				return blocks[block_mask[b]][l][r] + b * block_size;
			}

		public:
			lca(){}
			lca(int n, graph_type& g) :g(g),num_vertices(n) {
			
				euler_tour.reserve(2 * num_vertices);


				
				
			}
			~lca() {
				std::vector<int>().swap(euler_tour);
				
				std::vector<int>().swap(log_2);
				std::vector<std::vector<std::vector<int> > >().swap(blocks);
				std::vector<std::vector<int> >().swap(st);
				std::vector<int>().swap(block_mask);

			}
			void precompute_lca(dfs& dfs_visitor) {
				//std::vector<in_memory_vertex_descriptor* > outedges = g.root.successors_ref();
				// outdegree = outedges.size();
				dfs_visitor.dfs_lca(g, euler_tour);
				int m = euler_tour.size();

				log_2.reserve(m + 1);
				log_2.push_back(-1);

				for (size_t i = 1; i <= m; i++)
					log_2.push_back(log_2[i / 2] + 1);//log2
				block_size = std::max(1, log_2[m] / 2);

				block_cnt = (m  + block_size- 1) / block_size;
				//minimum of each block and build sparse table
				//st.resize(log_2[block_cnt] + 1, std::vector<int>(block_cnt,-1));
				
				st.assign(block_cnt, std::vector<int>(log_2[block_cnt] + 1));
				block_mask.assign(block_cnt, 0);//precompute mask for each block

				for (int i = 0, j = 0, b = 0; i < m; i++, j++) {
					if (j == block_size)
						j = 0, b++;
					if (j == 0|| min_by_h(i, st[b][0],dfs_visitor)==i)
						st[b][0] = i;
				}
				
				for (int l = 1; l < log_2[block_cnt]; l++)
				{
					for (int i = 0; i < block_cnt; i++)
					{
						int ni = i + (1 << (l - 1));
						if (ni >= block_cnt)
							st[i][l] = st[i][l - 1];
						else
							st[i][l] = min_by_h(st[i][l - 1], st[ni][l - 1],dfs_visitor);						
						
					}
				}
				

				block_mask.assign(block_cnt, 0);
				for (int i = 0, j = 0, b = 0; i < m; i++, j++) {
					if (j == block_size)
						j = 0, b++;
					if (j > 0 && (i >= m || min_by_h(i - 1, i, dfs_visitor) == i - 1))
						block_mask[b] += 1 << (j - 1);
				}
				
			

				// precompute RMQ for each unique block
				int possibilities = 1 << (block_size - 1);
				blocks.resize(possibilities);
				for (int b = 0; b < block_cnt; b++) {
					int mask = block_mask[b];
					if (!blocks[mask].empty())
						continue;
					blocks[mask].assign(block_size, std::vector<int>(block_size));
					for (int l = 0; l < block_size; l++) {
						blocks[mask][l][l] = l;
						for (int r = l + 1; r < block_size; r++) {
							blocks[mask][l][r] = blocks[mask][l][r - 1];
							if (b * block_size + r < m)
								blocks[mask][l][r] = min_by_h(b * block_size + blocks[mask][l][r], 
									b * block_size + r,dfs_visitor) - b * block_size;
						}
					}
				}
			}
			int lca_of_vertices(int v, int u,dfs& dfs_visitor) {
				int l = dfs_visitor .etime[v];
				int r = dfs_visitor .etime[u];
				if (l > r)
					std ::swap(l, r);
				int bl = l / block_size;
				int br = r / block_size;
				if (bl == br)
					return euler_tour[lca_in_block(bl, l % block_size, r % block_size)];
				int ans1 = lca_in_block(bl, l % block_size, block_size - 1);
				int ans2 = lca_in_block(br, 0, r % block_size);
				int ans = min_by_h(ans1, ans2,dfs_visitor);
				if (bl + 1 < br) {
					int l = log_2[br - bl - 1];
					int ans3 = st[bl + 1][l];
					int ans4 = st[br - (1 << l)][l];
					ans = min_by_h(ans, min_by_h(ans3, ans4,dfs_visitor),dfs_visitor);
				}
				return euler_tour[ans];
			}
			
			void dfs_precomputing(dfs& dfs_visitor) {
				dfs_visitor.dfs_lca(g, euler_tour);
			}
			int lca_of_vertices_no_precomputing(int v, int u, dfs& dfs_visitor) {
				int l = dfs_visitor.etime[v];
				int r = dfs_visitor.etime[u];
				if (l == r)
					return l;
				if (l > r)
					std::swap(l, r);
				int min_t = l;
				for (size_t i = l; i <= r; i++) {
					min_t = min_by_h(min_t, i, dfs_visitor);
				}
				return euler_tour[min_t];
			}
		};
	}
}