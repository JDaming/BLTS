#pragma once
#include <string>
#include <vector>
#include <utility>
#include <climits>

#include "types.h"
#include "offline_graph.h"
#include "dfs.h"
#include "spanning_tree.h"
#include "EdgeByBatch.h"
#include "in_graph.h"

namespace graph {
	void preprocessing2(std::string filename) {
		std::stringstream ss;
		inner_graph g;
		std::cout << "Now loading  graph" << std::endl;
		g.load(filename);
		std::cout << "load graph over! starting DFS" << std::endl;
		g.turn_to_dag();
		std::cout << "DFS-over" << std::endl;
		ss << filename << "dag";
		g.output(ss.str());
		std::cout << "output file over" << std::endl;
	}

	void preprocessing1(offline_graph& g) {
		edge_iterator  begin(g.filename.c_str()), end;
		std::string outfile = g.filename + "_no";
		std::ofstream o(outfile.c_str(), std::ios::out | std::ios::app);
		for (edge_iterator itor = begin; itor != end; ++itor) {			
			std::stringstream ss;
			ss << (itor->first.get_label()+1) << " " << (itor->second.get_label()+1) << std::endl;
			o << ss.str();
		}

	}

	void preprocessing3(std::string filename) {
		std::stringstream ss;
		inner_graph g;
		std::cout << "Now loading  graph" << std::endl;
		g.load(filename);
		std::cout << "load graph over! starting DFS" << std::endl;
		g.turn_to_dag2();
		std::cout << "DFS-over" << std::endl;
		ss << filename << "dag_2";
		g.output(ss.str());
		std::cout << "output file over" << std::endl;
	}

	void preprocessing_dblp(std::string filename) {
		inner_graph g;
		std::cout << "Now loading  graph" << std::endl;
		g.unregular_load(filename);
	}
	void random_generator(offline_graph& g, double rate)
	{
		std::stringstream ss;
		edge_iterator  begin(g.filename.c_str()), end;
		//std::string outfile = g.filename + "_" + std::string(int(rate*100));
		ss << g.filename << "_" << rate;
		std::ofstream o(ss.str(), std::ios::out | std::ios::app);
		std::default_random_engine e;
		std::uniform_real_distribution<double> u(0.0, 1.0);
		for (edge_iterator itor = begin; itor != end; ++itor) {			
			
			if (u(e) <= rate) {
				std::stringstream ss;
				ss << (itor->first.get_label()) << " " << (itor->second.get_label()) << std::endl;
				o << ss.str();
			}
		}
	}
}
