#pragma once
#include <iostream>

#include <stdio.h>
#include  "spanning_tree.h"

#include "types.h"

namespace graph {

	class level_node
	{
	private:
		vertex_label_t label;
		int parent;
		int level;
		std::vector<level_node* > successors;
	public:
		level_node()
		{
			label = 0;
			parent = 0;
			level = 0;
			successors.resize(0);
		}
		level_node(vertex_label_t l)
		{
			label = l;
		}
		~level_node() {
			//successors.clear();
			//std::vector<level_node*>().swap(successors);
		}
		bool operator ==(const level_node& rhs) const
		{
			return parent == rhs.parent && level == rhs.level && label == rhs.label && successors == rhs.successors;
		}
		
		level_node& operator =(level_node& rhs) 
		{
			this->level = rhs.level;
			this->parent = rhs.parent;
			this->label = rhs.label;
			this->successors = rhs.successors;
			return *this;
		}
		
		const vertex_label_t get_label() const { return this->label;}
		vertex_label_t& label_ref(){ return this->label;}
		const int get_level() const
		{
			return this->level;
		}
		int& level_ref()
		{
			return this->level;

		}
		const int get_parent() const
		{
			return this->parent;
		}
		
		int& parent_ref()
		{
			return this->parent;
		}
			
		const std::vector <level_node* >& get_successors() const
		{
			if (successors.size() > 0) {
				return successors;
			}
			else {
				throw
					std::logic_error("Attempt to get successors of descriptor which does not have them loaded.");
			}
		}
		std::vector <level_node* >& successors_ref()
		{
			return this->successors;
		} 
		
	};

	
	class lbtree
	{
	public:
		int num_nodes;
		level_node root;
		std::vector<level_node* >node_list;
	public:
		lbtree()
		{
			
		}
		lbtree(int n)
			: num_nodes(n)
		{
			root.label_ref() = ROOT_SIGN;
			root.label_ref() = 0;
			node_list.resize(n);
		}
		
		~lbtree()
		{
 			node_list.clear();
			std::vector<level_node*>().swap(node_list);
		}
		
		
		bool operator ==(const lbtree& rhs) const
		{
			return num_nodes == rhs.num_nodes && root == rhs.root  && node_list == rhs.node_list;
		}
		lbtree& operator =(lbtree& rhs)
		{
			this->num_nodes = rhs.num_nodes;
			this->root = rhs.root;
			this->node_list = rhs.node_list;
			return *this;
		}
		void generate(offline_graph& me);

	};
	
	
	namespace al
	{
		class SemiTS
		{
		private:
			std::string filename;
			
			int window_size;
			
			
			
			
			bool is_upedge(edge t);
			bool is_forwardedge(edge t);
			bool is_downedge(edge t);
			bool is_ancestor(level_node* u, level_node* v);
			bool is_ingroup(vertex_label_t u, std::vector<vertex_label_t> vec);

			void update_order();
			void update_order(level_node* u);
			void dfs_update(level_node* u, std::vector<color> & status);
			void remove_node(level_node* u, std::vector<color> & status, int l_min, int& remove_node_num);
			//void remove_edge(std::string filename);
		public:
			lbtree T;
			SemiTS();
			~SemiTS() {
				//delete &T;
			}
			//SemiTS(lbtree& tree, int memory_size, std::string file);
			SemiTS(offline_graph g, int memory_size);
			SemiTS& operator =(SemiTS& rhs)
			{
				this->filename = rhs.filename;
				this->window_size = rhs.window_size;
				this->T = rhs.T;
				return *this;
			}
			bool operator == (const SemiTS& rhs) const{
				return filename == rhs.filename && window_size == rhs.window_size && T == rhs.T;
			}
			//void init();
			//void restructure();
			void naiveSemiTS();
			void improveSemiTS();
			void improveSemiTS_it();
			void batchSemiTS();
			void batchSemiTS_it();
			void batchSemiTS_judge();
			
			
			
		};
	}
};