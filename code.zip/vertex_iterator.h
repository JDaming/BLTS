#pragma once
#include <iostream>
#include <string>
#include <sstream>
#include <boost/iterator/iterator_facade.hpp>
#include <fstream>
#include <cassert>
#include <stdio.h>

#include "vertex.h"

namespace graph {
	class vertex_iterator : public boost::iterator_facade<
		vertex_iterator,
		vertex_descriptor,
		boost::forward_traversal_tag,
		vertex_descriptor
	>
	{
	private:
		vertex_descriptor current_descriptor;
		FILE* back = NULL;
		std::string filename;
		size_t get_pos;
		bool end_marker;
		unsigned int num_vertices;

		void init() {
			get_pos = 0;
			end_marker = false;
			num_vertices = 0;
		}

		void copy(const vertex_iterator& other);

	public:
		vertex_iterator();

		vertex_iterator(const vertex_iterator& that);

		explicit vertex_iterator(const char* filename);

		virtual ~vertex_iterator();

		std::string as_str() const;

		vertex_iterator& operator = (const vertex_iterator& rhs);

		friend int outdegree(const vertex_iterator& me);
		friend const std::vector<vertex_label_t>& successors(const vertex_iterator& me);

	private:
		friend class boost::iterator_core_access;

		void increment();

		bool equal(const vertex_iterator& rhs) const {
			return ((this->current_descriptor.get_label() == rhs.current_descriptor.get_label()) &&
				!(this->end_marker || rhs.end_marker))
				|| (this->end_marker && rhs.end_marker);
		}

		vertex_descriptor dereference() const {
			return current_descriptor;
		}
	};

	int outdegree(const vertex_iterator& me);
	const std::vector<vertex_label_t>& successors(const vertex_iterator& me);
}