#pragma once
#include <vector>
#include <algorithm>
#include <iterator>
#include <iostream>
#include <exception>
#include <stdexcept>
#include <string>

#include "types.h"
namespace graph {
	class inner_node {
	private:
		vertex_label_t label;
		std::vector<vertex_label_t> successors;
	public:
		inner_node() {}
		inner_node(vertex_label_t l) {
			label = l;
		}

		operator inner_node()const {
			return label;
		}

		bool operator == (const inner_node& rhs) {
			label = rhs.label;
			successors = rhs.successors;
		}

		friend std::ostream& operator << (std::ostream& out, const inner_node& v);

		const vertex_label_t& get_label()const { return label; }
		vertex_label_t& label_ref() { return label; }

		const std::vector<vertex_label_t>& get_successors() const {
			if (successors.size() > 0)
				return successors;
			else
				throw
				std::logic_error("Attempt to get successors of descriptor which does not have them loaded.");
		}

		std::vector<vertex_label_t>& successors_ref() {
			return successors;
		}

		std::string as_str() const;

	};
}