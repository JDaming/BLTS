#pragma once
#ifndef TYPES_H_
#define TYPES_H_
#define ROOT_SIGN 0
#define VIRTUAL_SIGN 0





typedef unsigned char byte;
typedef long int vertex_label_t;
enum color {
	white, gray, black
};
#endif