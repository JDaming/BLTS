#pragma once
#ifndef GRAPH_H_
#define GRAPH_H_

#include <string>
#include <vector>
#include <utility>
#include <climits>

#include <boost/progress.hpp> //ʱ����
#include <boost/shared_ptr.hpp>

#include "types.h"
#include "offline_graph.h"

class graph
{
private:
	const static int STD_BUFFER_SIZE = 1024 * 1024;

	/** The compression flags used. */
	int flags;

	/**
	* Internal successor iterator nodeer - used because internal iterators
	* are polymorphic and thus must be manipulated through nodeers.
	*/

};

#endif 
