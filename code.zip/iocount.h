#pragma once
#include <iostream>


namespace graph {
#ifdef DEBUG
	extern long int io_num;
	extern long int io_read;
	extern long int io_write;

	extern long int tree_edge_num;
#endif // DEBUG
}


