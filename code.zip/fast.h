#pragma once
#ifndef FAST_H_
#define FAST_H_

#include <string>
#include <sstream>

namespace utils {

	int int2nat(int x);
	int nat2int(int x);

	std::string byte_to_binary(int x);
	std::string int_to_binary(long x, int len);
	std::string byte_as_hex(int byte);

	template<class T>
	std::string to_string(const T& thing) {
		std::ostringstream o;

		o << thing;

		return o.str();
	}

}

#endif
