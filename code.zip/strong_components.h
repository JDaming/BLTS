#pragma once
#include <iostream>
#include "spanning_tree.h"
#include "dfs.h"
namespace graph {
	namespace al {
		int strong_components(spanning_tree & g, dfs& dfs_visitor) {
			dfs_visitor.dfs_node(g.s.get_label(), 0, g);
		}
	
	}
}