#include <iostream>
#include <fstream>
#include <exception>

#include "ibitstream.h"
#include "fast.h"

#define LOGGING


namespace graph {


	int ibitstream::read() {
#ifdef LOGGING
		std::cerr << "Read called. unget_count = " << unget_count << std::endl;
#endif

		if (unget_count > 0)
			//      return unget_bytes[ --unget_count ] & 0xFF;
			return unget_bytes.at(--unget_count) & 0xff;

		if (past_eof)
			return 0;

		// simple case
		if (no_buffer) {
			int t = is->get();
			if (!is->good()) {
				assert(overflow);
				past_eof = true;
				return 0;
			}
			else
				position++;
#ifdef LOGGING      
			std::cerr << "About to return byte " << (unsigned int)((unsigned char)t)
				<< " just read from file.\n";
#endif
			return t & 0xFF;
		}

		// deal with reading into the buffer.
		if (avail == 0) {
			// then the buffer is empty. attempt to fill it again.
			if (is != NULL)
				assert(buffer->size() == buffer->capacity());
			avail = is->readsome((char*)&(*buffer).at(0), buffer->size()); // used to be capacity
#ifdef LOGGING         
			std::cerr << "==================================================\n";
			std::cerr << "BUFFER REFILLED; first 50 bytes : \n";
			for (int i = 0; i < 50; i++) {
				std::cerr << utils::int_to_binary((*buffer).at(0), 8) << " ";
				if (i + 1 % 10 == 0)
					std::cerr << "\n";
			}
			std::cerr << "\n";
#endif
			if (avail == 0) {
				if (overflow) {
					past_eof = true;
					return 0;
				}
				else {
					throw eof_exception();
				}
			}
			else {
				position += pos;
				pos = 0;
			}
		}

		avail--;

		int retval = (*buffer).at(pos++) & 0xFF;
#ifdef LOGGING
		std::cerr << "read() - About to return byte " << utils::int_to_binary(retval, 8)
			<< " just read from buffer (pos now = " << pos << ").\n";
#endif
		return retval;
	}


	int ibitstream::read_from_current(unsigned int len) {
		//   assert( len <= 8 );
		if (len == fill) {
			// We just empty everything.
			read_bits += len;
			fill = 0;
			int retval = current & (1 << len) - 1;
#ifdef LOGGING
			std::cerr << "\tread_from_current(" << len << ") = " << retval << " "
				<< "(current=" << utils::int_to_binary(current, fill) << ")\n";
#endif
			return retval;
		}

		if (fill == 0) {
			current = read();
#ifdef LOGGING
			std::cerr << "\tread_from_current - just read " << utils::int_to_binary(current, 8)
				<< "into current.\n";
#endif
			fill = 8;
		}

		assert(len <= fill);

		read_bits += len;
		// used to be (unsigned)current on following line.
		int retval = (current >> (fill -= len)) & ((1 << len) - 1);
#ifdef LOGGING
		std::cerr << "read_from_current(" << len << ") = " << retval << " "
			<< "(current=" << utils::int_to_binary(current, fill) << ")\n";
#endif
		return retval;
	}

	void ibitstream::read(byte bits[], unsigned int len) {
		if (fill < 8)
			refill();

		if (len <= fill) {
			if (len <= 8) {
				bits[0] = (byte)(read_from_current(len) << 8 - len);
				return;
			}
			else {
				bits[0] = (byte)(read_from_current(8));
				bits[1] = (byte)(read_from_current(len - 8) << 16 - len);
				return;
			}
		}
		else {
			int i, j = 0, b;

			if (fill >= 8) {
				bits[j++] = (byte)(read_from_current(8));
				len -= 8;
			}

			const unsigned int shift = fill;

			bits[j] = (byte)(read_from_current(shift) << 8 - shift);
			len -= shift;

			i = len >> 3;
			while (i-- != 0) {
				b = read();
				// used to be >>>
				bits[j] |= ((b & 0xFF) >> shift) & 0xFF; // the last & 0xFF is mine.
				bits[++j] = (byte)(b << 8 - shift);
			}

			read_bits += len & ~7;

			len &= 7;
			if (len != 0) {
				if (len <= 8 - shift) {
					bits[j] |= (byte)(read_from_current(len) << 8 - shift - len);
				}
				else {
					bits[j] |= (byte)(read_from_current(8 - shift));
					bits[j + 1] = (byte)(read_from_current(len + shift - 8) << 16 - shift - len);
				}
			}
		}
	}



	int ibitstream::read_int(unsigned int len) {
		int i, x = 0;

#ifdef LOGGING
		std::cerr << "read_int( " << len << " ) called... " << std::endl;
#endif

		assert(len >= 0 && len <= 32);

		if (len <= fill) {
			int retval = read_from_current(len);
#ifdef LOGGING
			std::cerr << "read_int_1(" << len << ") = " << retval << "\n";
#endif
			return retval;
		}

		len -= fill;
		x = read_from_current(fill);

		i = len >> 3;
		while (i-- != 0) x = x << 8 | read();
		read_bits += len & ~7;

		len &= 7;

		int retval = (x << len) | read_from_current(len);

#ifdef LOGGING
		std::cerr << "read_int_2( " << len << ") = " << retval << "\n";
#endif

		return retval;
	}

	long ibitstream::skip(unsigned long n) {
#ifdef LOGGING
		std::cerr << "skip(n)......." << "\n";
#endif

		if (n <= fill) {
			assert(n >= 0);
			fill -= n;
			read_bits += n;
			return n;
		}
		else {
			const long prev_read_bits = read_bits;

			n -= fill;
			read_bits += fill;
			fill = 0;

			unsigned long nb = n >> 3;

			if (!no_buffer && nb > avail && nb < avail + buffer->size()) {
				/* If we can skip by simply filling the buffer and skipping some bytes,
				we do it. Usually the next block has already been fetched by a read-ahead logic. */
				read_bits += (avail + 1) << 3;
				n -= (avail + 1) << 3;
				nb -= avail + 1;
				position += pos + avail;
				pos = avail = 0;
				read();
			}

			if (nb <= avail) {
				// We skip bytes directly inside the buffer.
				pos += (int)nb;
				avail -= (std::streamoff)nb;
				read_bits += n & ~7;
			}
			else {
				// No way, we have to pass the byte skip to the underlying stream.
				n -= avail << 3;
				read_bits += avail << 3;

				const long to_skip = nb - avail;
				const long prev_pos = is->tellg();
				is->ignore(to_skip);
				const long skipped = is->tellg() - (std::streamoff)prev_pos;

				position += (avail + pos) + skipped;
				pos = 0;
				avail = 0;

				read_bits += skipped << 3;

				if (skipped != to_skip)
					return read_bits - prev_read_bits;
			}

			const int residual = (int)(n & 7);
			if (residual != 0) {
				current = read();
				fill = 8 - residual;
				read_bits += residual;
			}
			return read_bits - prev_read_bits;
		}
	}


	void ibitstream::set_position(unsigned long position) {
#ifdef LOGGING
		std::cerr << "set_position called...\n";
#endif

		assert(position >= 0);

		// removed "unsigned"
		const int delta = (position >> 3) - (this->position + pos);

		// Once graph memory is attached, we should be looking there.
		// But for some reason, we're looking in the (null) istream instead.

		int pos = (int)this->pos;

		if (delta <= avail && delta >= -pos) {
			// We can reposition just by moving into the buffer.
			avail -= delta;
			pos += delta;
			fill = unget_count = 0;
		}
		else {
			flush();
			is->seekg(position >> 3);
			this->position = position >> 3;
		}

		int residual = (int)(position & 7);

		if (residual != 0) {
			current = read();
			fill = 8 - residual;
		}
	}

}