#pragma once
#include <iostream>
#include <fstream>
#include <algorithm>
#include <utility>


#include "spanning_tree.h"
#include "vertex.h"




namespace graph {

	
	class inner_graph {
	
	public:
		
		spanning_tree T;
		void load(std::string& filename);
		void unregular_load(std::string & filename);
		void turn_to_dag();

		void turn_to_dag2();

		void dfs_node(vertex_label_t u, std::vector<color>& status);

		void dfs_node2(vertex_label_t u, std::vector<color>& status);

		void output(std::string filename);

		//void output();

		//void dfs_node(vertex_label_t u, std::vector<color>& status, int & t, std::vector<int>& dtime, std::vector<int>& ftime);


		

	};


}