#include <sstream>
#include <iostream>
#include <queue>
#include <algorithm>
#include <tr1/unordered_map>
#include <stdio.h>
#include <string.h>
#include <time.h>

#include "SemiTS.h"
#include "edge_iterator.h"
#include "dfs.h"
#include "iocount.h"
#include "types.h"

void graph::lbtree::generate(offline_graph& me)
{
	num_nodes = me.get_num_nodes() + 1;
	node_list.resize(num_nodes);
	
	for (size_t i = 0; i < num_nodes; i++)
	{
		node_list[i] = new level_node();
		node_list[i]->label_ref() = i;
		node_list[i]->level_ref() = 1;
	}
	
	edge_iterator begin, end;
	
	tie(begin, end) = me.get_edge_iterator();
	
	root.label_ref() = ROOT_SIGN;
	root.level_ref() = 0;
	
	bool* status = new bool[num_nodes];
	for (size_t i = 0; i < num_nodes; i++)
		status[i] = true;
	
	for (edge_iterator itor = begin; itor != end; ++itor)
	{
		if (status[itor->second.get_label()] == true)
		{
			tree_edge_num++;
			node_list[itor->first.get_label()]->successors_ref().push_back(node_list[itor->second.get_label()]);
			node_list[itor->second.get_label()]->parent_ref() = itor->first.get_label();
			//node_list[itor->second.get_label()]->level_ref() = node_list[itor->first.get_label()]->level_ref() + 1;
			status[itor->second.get_label()] = false;
		}
		
	}
	
	for (size_t i = 1; i < num_nodes; i++) {
		
		if (status[i] == true) {
			tree_edge_num++;
			root.successors_ref().push_back(node_list[i]);
			node_list[i]->parent_ref() = ROOT_SIGN;
			node_list[i]->level_ref() = root.get_level() + 1;
		}
	}
		
	node_list[0] = &root;
	delete []status;
	
	std::queue<level_node*> qlist;
	qlist.push(&root);

	while (!qlist.empty()) {
		level_node* u = qlist.front();
		qlist.pop();
		//std::cout << &(u->successors_ref()) << std::endl;
		std::vector<level_node* >(u->successors_ref()).swap(u->successors_ref());
		//std::cout << &(u->successors_ref()) << std::endl;
		for (size_t i = 0; i < u->successors_ref().size(); i++)
		{
			u->successors_ref()[i]->level_ref() = u->level_ref() + 1;
			qlist.push(u->successors_ref()[i]);
		}
	}
}

graph::al::SemiTS::SemiTS()
{
	
}

graph::al::SemiTS::SemiTS(offline_graph g, int memory_size)
{
	window_size = memory_size;
	//edge_memory.resize(window_size / sizeof(edge));
	filename = g.filename;
	T.generate(g);
}



void graph::al::SemiTS::improveSemiTS()
{
	bool update = true;
	int count = 0;

	//	int l_max = 0;
	FILE *result = fopen("final_result", "w+");

	
	int remove_node_num = 0;
	while (update == true)
	{
#ifdef DEBUG
		std::cout << "iteration start" << std::endl;
		clock_t start = clock();
#endif // DEBUG
		++count;
		std::stringstream ss;
		ss << filename << count;
		//boost::shared_ptr<std::ofstream> out(new std::ofstream);
		//out->open(ss.str().c_str(), std::ios::out);
		
		int l_min = T.num_nodes;
		update = false;
		edge_iterator  begin(filename.c_str()), end;
		
		for (edge_iterator itor = begin; itor != end; ++itor)
		{

			if (is_upedge(*itor))
			{
				update = true;
				level_node* w = T.node_list[T.node_list[itor->second.get_label()]->get_parent()];
				for (size_t i = 0; i < w->successors_ref().size(); i++)
					if (w->successors_ref()[i]->get_label() == itor->second.get_label()) {
						//w->successors_ref().erase(w->successors_ref().begin() + i);
						std::swap(w->successors_ref()[i], w->successors_ref()[w->successors_ref().size()-1]);
						w->successors_ref().pop_back();
					}
							
				T.node_list[itor->first.get_label()]->successors_ref().push_back(T.node_list[itor->second.get_label()]);
				T.node_list[itor->second.get_label()]->parent_ref() = itor->first.get_label();

				l_min = std::min(l_min, T.node_list[itor->second.get_label()]->get_level());

				T.node_list[itor->second.get_label()]->level_ref() = T.node_list[itor->first.get_label()]->get_level() + 1;
	//	l_max = std::max(l_max, T.node_list[itor->first.get_label()]->get_level());
			}
/*
if (is_downedge(*itor))
{
	l_max = std::max(l_max, T.node_list[itor->second.get_label()]->get_level());
}*/

		}
#ifdef DEBUG
		//dfs dfs_visitor;
		//dfs_visitor.dfs_travel(T);
		clock_t handle_edge_time = clock();
		std::cout << "time:" << (double)(handle_edge_time - start) / CLOCKS_PER_SEC << "s" << std::endl;

#endif // DEBUG
		std::queue<level_node* > qlist;
		// update order and rmove node
		for (size_t i = 0; i < T.root.successors_ref().size(); i++)
		{
			qlist.push(T.root.successors_ref()[i]);
		}

		while (!qlist.empty())
		{
			level_node* u = qlist.front();
			qlist.pop();

			for (size_t i = 0; i < u->successors_ref().size(); i++)
			{
				u->successors_ref()[i]->level_ref() = u->level_ref() + 1;
				qlist.push(u->successors_ref()[i]);
			}

		}
		//remove node 
		std::vector<color> status;
		status.assign(T.num_nodes, white);
		if (T.root.successors_ref()[1]->get_level() < l_min) {
			std::vector<level_node*> list;
			level_node* u;
			for (size_t i = 0; i < T.root.successors_ref().size(); i++) {
				list.push_back(T.root.successors_ref()[i]);
				remove_node_num++;
			}

			for (size_t i = 0; i < list.size(); i++) {
				remove_node(list[i], status, l_min, remove_node_num);
			}
			T.root.successors_ref().erase(T.root.successors_ref().begin(), T.root.successors_ref().begin() + list.size());

		}
		T.root.level_ref() = l_min - 1;

		
#ifdef DEBUG
		clock_t remove_time = clock();
		std::cout << "time:" << (double)(remove_time - handle_edge_time) / CLOCKS_PER_SEC << "s" << std::endl;
#endif // DEBUG



		FILE *wt_fd = fopen(ss.str().c_str(), "w+");
		FILE * rd_fd = fopen(filename.c_str(), "r");

		size_t len = 4096 + 1;

		char* wt_buf = new char[BUFSIZ];
		char* line = new char[len];

		int buf_offset = 0;
		int line_offset = 0;
		ssize_t nread;
		//edge_iterator  begin(filename.c_str()), end;
		while (getline(&line, &len, rd_fd) != -1){

			nread = strlen(line);
#ifdef DEBUG
			io_num += nread;
			io_read += nread;
#endif // DEBUG
			std::istringstream iss(line);
			edge tmp;
			iss >> tmp.first.label_ref();
			iss >> tmp.second.label_ref();
			int source_level = T.node_list[tmp.first.get_label()]->get_level();
			int target_level = T.node_list[tmp.second.get_label()]->get_level();
		
			//hm_itor = remove_map.find(tmp.first.get_label());
			if(T.node_list[tmp.first.get_label()]->get_level() >= l_min && !(is_forwardedge(tmp))) {
				if (buf_offset + nread < BUFSIZ) {
					memcpy(wt_buf + buf_offset, line, nread);
					buf_offset += nread;
				}
				else {

					memcpy(wt_buf + buf_offset, line, BUFSIZ - buf_offset);
					line_offset = BUFSIZ-buf_offset;
#ifdef DEBUG
					io_num += BUFSIZ;
					io_write += BUFSIZ;
#endif // DEBUG
					fwrite(wt_buf, sizeof(char), BUFSIZ, wt_fd);
					memcpy(wt_buf, line + line_offset, nread - line_offset);
					buf_offset = nread - line_offset;
					line_offset = 0;
				}
			}
		}
		fwrite(wt_buf, sizeof(char), buf_offset, wt_fd);
#ifdef DEBUG
		io_num += buf_offset;
		io_write += buf_offset;
#endif // DEBUG
		fclose(wt_fd);

		
			
	

#ifdef DEBUG
		clock_t rewrite_time = clock();
		std::cout << "time:" << (double)(rewrite_time-remove_time) / CLOCKS_PER_SEC << "s" << std::endl;

#endif // DEBUG

		filename = ss.str();
		
		
#ifdef DEBUG
		clock_t end_time = clock();
		std::cout << "time:" << (double)(end_time - start) / CLOCKS_PER_SEC << "s" << std::endl;
		std::cout << "iteration over" << std::endl;
#endif // DEBUG
	}
	fclose(result);
	
}


void graph::al::SemiTS::improveSemiTS_it()
{
	bool update = true;
	int count = 0;

	//	int l_max = 0;
	FILE *result = fopen("final_result", "w+");

	
	int remove_node_num = 0;
	while (update == true)
	{
#ifdef DEBUG
		std::cout << "iteration start" << std::endl;
		clock_t start = clock();
#endif // DEBUG
		++count;
		std::stringstream ss;
		ss << filename << count;
		//boost::shared_ptr<std::ofstream> out(new std::ofstream);
		//out->open(ss.str().c_str(), std::ios::out);
		
		int l_min = T.num_nodes;
		update = false;
		edge_iterator  begin(filename.c_str()), end;
		
		for (edge_iterator itor = begin; itor != end; ++itor)
		{

			if (is_upedge(*itor))
			{
				update = true;
				level_node* w = T.node_list[T.node_list[itor->second.get_label()]->get_parent()];
				for (size_t i = 0; i < w->successors_ref().size(); i++)
					if (w->successors_ref()[i]->get_label() == itor->second.get_label()) {
						//w->successors_ref().erase(w->successors_ref().begin() + i);
						std::swap(w->successors_ref()[i], w->successors_ref()[w->successors_ref().size() - 1]);
						w->successors_ref().pop_back();
					}
							
				T.node_list[itor->first.get_label()]->successors_ref().push_back(T.node_list[itor->second.get_label()]);
				T.node_list[itor->second.get_label()]->parent_ref() = itor->first.get_label();

				l_min = std::min(l_min, T.node_list[itor->second.get_label()]->get_level());

				T.node_list[itor->second.get_label()]->level_ref() = T.node_list[itor->first.get_label()]->get_level() + 1;
				//	l_max = std::max(l_max, T.node_list[itor->first.get_label()]->get_level());
			}
			/*
			if (is_downedge(*itor))
			{
				l_max = std::max(l_max, T.node_list[itor->second.get_label()]->get_level());
				}*/

		}
#ifdef DEBUG
		dfs dfs_visitor;
		dfs_visitor.dfs_travel(T);
		clock_t handle_edge_time = clock();
		std::cout << "time:" << (double)(handle_edge_time - start) / CLOCKS_PER_SEC << "s" << std::endl;

#endif // DEBUG
		std::queue<level_node* > qlist;
		// update order and rmove node
		for(size_t i = 0 ; i < T.root.successors_ref().size() ; i++)
		{
			qlist.push(T.root.successors_ref()[i]);
		}

		while (!qlist.empty())
		{
			level_node* u = qlist.front();
			qlist.pop();

			for (size_t i = 0; i < u->successors_ref().size(); i++)
			{
				u->successors_ref()[i]->level_ref() = u->level_ref() + 1;
				qlist.push(u->successors_ref()[i]);
			}

		}
		//remove node 
		std::vector<color> status;
		status.assign(T.num_nodes, white);
		if (T.root.successors_ref()[1]->get_level() < l_min) {
			std::vector<level_node*> list;
			level_node* u;
			for (size_t i = 0; i < T.root.successors_ref().size(); i++) {
				list.push_back(T.root.successors_ref()[i]);
				remove_node_num++;
			}

			for (size_t i = 0; i < list.size(); i++) {
				remove_node(list[i], status, l_min, remove_node_num);
			}
			T.root.successors_ref().erase(T.root.successors_ref().begin(), T.root.successors_ref().begin() + list.size());

		}
		T.root.level_ref() = l_min - 1;

		
#ifdef DEBUG
		clock_t remove_time = clock();
		std::cout << "time:" << (double)(remove_time - handle_edge_time) / CLOCKS_PER_SEC << "s" << std::endl;
#endif // DEBUG



		FILE *wt_fd = fopen(ss.str().c_str(), "w+");
		FILE * rd_fd = fopen(filename.c_str(), "r");

		size_t len = 4096 + 1;

		char* wt_buf = new char[BUFSIZ];
		char* line = new char[len];

		int buf_offset = 0;
		int line_offset = 0;
		ssize_t nread;
		//edge_iterator  begin(filename.c_str()), end;
		while(getline(&line, &len, rd_fd) != -1) {

			nread = strlen(line);
#ifdef DEBUG
			io_num += nread;
			io_read += nread;
#endif // DEBUG
			std::istringstream iss(line);
			edge tmp;
			iss >> tmp.first.label_ref();
			iss >> tmp.second.label_ref();
			int s_level = T.node_list[tmp.first.get_label()]->get_level();
			int e_level = T.node_list[tmp.second.get_label()]->get_level();
			//hm_itor = remove_map.find(tmp.first.get_label());
			if(s_level >= l_min && !((dfs_visitor.dtime[tmp.first.get_label()]<dfs_visitor.dtime[tmp.second.get_label()] && dfs_visitor.ftime[tmp.first.get_label()]>dfs_visitor.ftime[tmp.second.get_label()]) && (s_level < e_level) )){
				if (buf_offset + nread < BUFSIZ) {
					memcpy(wt_buf + buf_offset, line, nread);
					buf_offset += nread;
				}
				else {

					memcpy(wt_buf + buf_offset, line, BUFSIZ - buf_offset);
					line_offset = BUFSIZ - buf_offset;
#ifdef DEBUG
					io_num += BUFSIZ;
					io_write += BUFSIZ;
#endif // DEBUG
					fwrite(wt_buf, sizeof(char), BUFSIZ, wt_fd);
					memcpy(wt_buf, line + line_offset, nread - line_offset);
					buf_offset = nread - line_offset;
					line_offset = 0;
				}
			}
		}
		fwrite(wt_buf, sizeof(char), buf_offset, wt_fd);
#ifdef DEBUG
		io_num += buf_offset;
		io_write += buf_offset;
#endif // DEBUG
		fclose(wt_fd);

		
			
	

#ifdef DEBUG
		clock_t rewrite_time = clock();
		std::cout << "time:" << (double)(rewrite_time - remove_time) / CLOCKS_PER_SEC << "s" << std::endl;

#endif // DEBUG

		filename = ss.str();
		
		
#ifdef DEBUG
		clock_t end_time = clock();
		std::cout << "time:" << (double)(end_time - start) / CLOCKS_PER_SEC << "s" << std::endl;
		std::cout << "iteration over" << std::endl;
#endif // DEBUG
	}
	fclose(result);
	
}


void graph::al::SemiTS::batchSemiTS()
{
	bool update = true;
	int count = 0;
	
	//	int l_max = 0;
	//std::string outfile("final");
	//boost::shared_ptr<std::ofstream> result(new std::ofstream);

	FILE *result = fopen("final_result", "w+");
	//result->open(outfile.c_str(), std::ios::out);
	dfs dfs_visitor;
	std::vector<vertex_label_t> order;
	while (update == true)
	{
#ifdef DEBUG
		std::cout << "iteration start" << std::endl;
		clock_t start = clock();
#endif // DEBUG

		
		
		int l_min = T.num_nodes;
		++count;
		std::stringstream ss;
		ss << filename << count;
		//boost::shared_ptr<std::ofstream> out(new std::ofstream);
		//out->open(ss.str().c_str(), std::ios::out);
		
		int window_ptr = 0;
		update = false;
		edge_iterator  begin(filename.c_str()), end;
		std::vector<color> status;
		int remove_node_num = 0;
		for (edge_iterator itor = begin; itor != end; ++itor)
		{

			//tree_edge_num++;
			/*
			 *we do not check whether is the edge itor is a tree-edge, which means it may exsit repeat edges in T, but we do check it in our comparative algorithm, which not influence the result
			 *
			 **/
			T.node_list[itor->first.get_label()]->successors_ref().push_back(T.node_list[itor->second.get_label()]);
			//std::cout << "edge:" << itor->first.get_label() << " " << itor->second.get_label() << std::endl;
			window_ptr++;
			if (window_ptr == (window_size + remove_node_num))
			{
				
				std::vector<vertex_label_t >().swap(order);
				//order.assign(T.num_nodes, -1);
				dfs_visitor.dfs_ts(T, order); //attention, 
				
				
				
				std::reverse(order.begin(), order.end());
				
				
				for (size_t i = 0; i < order.size(); i++) {
					for (size_t j = 0; j < T.node_list[order[i]]->successors_ref().size(); j++)
					{
						
						if (T.node_list[order[i]]->successors_ref()[j]->get_level() <= T.node_list[order[i]]->get_level()) {
							l_min = std::min(l_min, T.node_list[order[i]]->successors_ref()[j]->get_level());
							T.node_list[order[i]]->successors_ref()[j]->level_ref() = T.node_list[order[i]]->get_level() + 1;
							//T.node_list[T.node_list[order[i]]->successors_ref()[j]->get_parent()]
							//T.node_list[order[i]]->successors_ref()[j]->parent_ref() = T.node_list[order[i]]->get_label();
							
							update = true;
						}
						else if (T.node_list[order[i]]->get_level() < T.node_list[order[i]]->successors_ref()[j]->get_level() - 1) {
							//T.node_list[order[i]]->successors_ref().erase(T.node_list[order[i]]->successors_ref().begin() + j);
							std::swap(T.node_list[order[i]]->successors_ref()[j], T.node_list[order[i]]->successors_ref()[T.node_list[order[i]]->successors_ref().size()-1]);
							T.node_list[order[i]]->successors_ref().pop_back();
						//	tree_edge_num--;
							j--;
						}
					}
				}
				
				
				
				status.assign(T.num_nodes, white);
				
				dfs_update(T.node_list[0], status);
				
				//dfs_visitor.free_space();
				
				window_ptr = 0;
				for (size_t i = 0; i < T.num_nodes; i++)
					std::vector<level_node* >(T.node_list[i]->successors_ref()).swap(T.node_list[i]->successors_ref());
			}
			
		}

		//handle left edges
			if (window_ptr > 0) {
			std::vector<vertex_label_t >().swap(order);
			//order.assign(T.num_nodes, -1);
			dfs_visitor.dfs_ts(T, order); //attention, 



			std::reverse(order.begin(), order.end());


			for (size_t i = 0; i < order.size(); i++) {
				for (size_t j = 0; j < T.node_list[order[i]]->successors_ref().size(); j++)
				{
					if (T.node_list[order[i]]->successors_ref()[j]->get_level() <= T.node_list[order[i]]->get_level()) {
						l_min = std::min(l_min, T.node_list[order[i]]->successors_ref()[j]->get_level());
						T.node_list[order[i]]->successors_ref()[j]->level_ref() = T.node_list[order[i]]->get_level() + 1;
						//T.node_list[T.node_list[order[i]]->successors_ref()[j]->get_parent()]
						//T.node_list[order[i]]->successors_ref()[j]->parent_ref() = T.node_list[order[i]]->get_label();

						update = true;
					}
					else if (T.node_list[order[i]]->get_level() < T.node_list[order[i]]->successors_ref()[j]->get_level() - 1) {
						//T.node_list[order[i]]->successors_ref().erase(T.node_list[order[i]]->successors_ref().begin() + j);
						std::swap(T.node_list[order[i]]->successors_ref()[j], T.node_list[order[i]]->successors_ref()[T.node_list[order[i]]->successors_ref().size()-1]);
						T.node_list[order[i]]->successors_ref().pop_back();
						j--;
						tree_edge_num--;
					}
				}
			}



			status.assign(T.num_nodes, white);

			dfs_update(T.node_list[0], status);
			

			for (size_t i = 0; i < T.num_nodes; i++)
				std::vector<level_node* >(T.node_list[i]->successors_ref()).swap(T.node_list[i]->successors_ref());
		
			window_ptr = 0;
		}





#ifdef DEBUG
		clock_t handle_edge_time = clock();
		std::cout << "time:" << (double)(handle_edge_time - start) / CLOCKS_PER_SEC << "s" << std::endl;

#endif // DEBUG
		
	
		/*
		 *NodeRemove
		 **/
		std::stringstream s_str;
		status.assign(T.num_nodes, white);
		if (T.root.successors_ref().size()>0 && T.root.successors_ref()[0]->get_level() < l_min) {
			std::vector<level_node*> list;
			level_node* u;
			for (size_t i = 0; i < T.root.successors_ref().size(); i++) {
				list.push_back(T.root.successors_ref()[i]);
				remove_node_num++;
			}
		
			for(size_t i = 0; i<list.size(); i++){				
				remove_node(list[i], status, l_min, remove_node_num);
			}
			T.root.successors_ref().erase(T.root.successors_ref().begin(), T.root.successors_ref().begin() + list.size());

			std::vector<level_node* >(T.root.successors_ref()).swap(T.root.successors_ref());
			//tree_edge_num -= list.size();
		}
		T.root.level_ref() = l_min-1;
		
		//std::vector<vertex_label_t > remove_node;
		//std::tr1::unordered_map<vertex_label_t, int> remove_map;
		//std::tr1::unordered_map<vertex_label_t, int>::iterator hm_itor;
		

		

		std::vector<color>().swap(status);
#ifdef DEBUG
		clock_t remove_time = clock();
	//	std::wcout << "remove_node:" << rm_node_count << std::endl;
		std::cout << "time:" << (double)(remove_time - handle_edge_time) / CLOCKS_PER_SEC << "s" << std::endl;

#endif // DEBUG
		int rm_edge_count = 0;
		
		FILE *wt_fd = fopen(ss.str().c_str(), "w+");
		FILE * rd_fd = fopen(filename.c_str(), "r");

		size_t len = BUFSIZ;

		char* wt_buf = new char[BUFSIZ];
		char* line = new char[len];

		int buf_offset = 0;
		int line_offset = 0;
		ssize_t nread;
		//edge_iterator  begin(filename.c_str()), end;
		while (getline(&line, &len, rd_fd) != -1){

			nread = strlen(line);
#ifdef DEBUG
			io_num += nread;
			io_read += nread;
#endif // DEBUG
			std::istringstream iss(line);
			edge tmp;
			iss >> tmp.first.label_ref();
			iss >> tmp.second.label_ref();

			int s_level = T.node_list[tmp.first.get_label()]->get_level();
			int e_level = T.node_list[tmp.second.get_label()]->get_level();
			//hm_itor = remove_map.find(tmp.first.get_label());
			if(s_level >= l_min && !((dfs_visitor.dtime[tmp.first.get_label()]<dfs_visitor.dtime[tmp.second.get_label()] && dfs_visitor.ftime[tmp.first.get_label()]>dfs_visitor.ftime[tmp.second.get_label()]) && (s_level < e_level) )){
				rm_edge_count++;
				if (buf_offset + nread < BUFSIZ) {
					memcpy(wt_buf + buf_offset, line, nread);
					buf_offset += nread;
				}
				else {

					memcpy(wt_buf + buf_offset, line, BUFSIZ - buf_offset);
					line_offset = BUFSIZ - buf_offset;
					buf_offset = nread - line_offset;
					//fputs(wt_buf, wt_fd);
#ifdef DEBUG
					io_num+=BUFSIZ;
					io_write+=BUFSIZ;
#endif // DEBUG
					fwrite(wt_buf, sizeof(char), BUFSIZ, wt_fd);
					memcpy(wt_buf, line + line_offset, nread - line_offset);
				
					line_offset = 0;
				}
			}
		}
		fwrite(wt_buf, sizeof(char), buf_offset, wt_fd);

		fclose(wt_fd);
		dfs_visitor.free_space();
		delete[]line;
		delete[]wt_buf;
		//delete &dfs_visitor;
		
		/*
	
		for (edge_iterator itor = begin; itor != end; ++itor)
		{
			bool tmp_flag1 = false;
			bool tmp_flag2 = false;
			if (dfs_visitor.dtime[itor->first.get_label()]<dfs_visitor.dtime[itor->second.get_label()] &&  dfs_visitor.ftime[itor->first.get_label()]>dfs_visitor.ftime[itor->second.get_label()])
			{
				tmp_flag1 = true;
			}
			
			if (!tmp_flag1) {
				for (size_t i = 0; i < remove_node.size(); i++)
				{

					if (itor->first.get_label() == remove_node[i]){
						tmp_flag2 = true;
						break;
					}
				}
				if (!tmp_flag2) {
#ifdef DEBUG
					io_num++;
					io_write++;
#endif // DEBUG
					*out << itor->first.get_label() << " " << itor->second.get_label() << std::endl;
				}
			}
		}
		*/
		filename = ss.str();
#ifdef DEBUG
		clock_t end_time = clock();
		std::cout << "remove_edge_count:" << rm_edge_count << std::endl;
		std::cout << "time:" << (double)(end_time - start) / CLOCKS_PER_SEC << "s" << std::endl;
		std::cout << "iteration over" << std::endl;
		
#endif // DEBUG

	}

	fclose(result);

	
}

/*

void graph::al::SemiTs::batchSemiTS() {
	bool update = true;
	int count = 0;

	//	int l_max = 0;
	//std::string outfile("final");
	//boost::shared_ptr<std::ofstream> result(new std::ofstream);

	FILE *result = fopen("final_result", "a");
	//result->open(outfile.c_str(), std::ios::out);
	dfs dfs_visitor;

	while (update == true) {
		update = false;
	}
}
*/


void graph::al::SemiTS::naiveSemiTS()
{
#ifdef DEBUG
	std::cout << "starting updating" << std::endl;
#endif
	bool update = true;
	
	while (update == true)
	{
#ifdef DEBUG
		std::cout << "iteration start" << std::endl;
#endif
		update = false;
		edge_iterator  begin(filename.c_str()), end;
		int count = 0;
		for (edge_iterator itor = begin; itor != end; ++itor)
		{

			if (is_upedge(*itor))
			{	
				count++;
				//std::cout << "upedge:" << itor->first.get_label() << " " << itor->second.get_label() << std::endl;
				update = true;
				level_node* w = T.node_list[T.node_list[itor->second.get_label()]->get_parent()];
				for (size_t i = 0; i < w->successors_ref().size(); i++)
					if (w->successors_ref()[i]->get_label() == itor->second.get_label()) {
						std::swap(w->successors_ref()[i], w->successors_ref()[w->successors_ref().size() - 1]);
						w->successors_ref().pop_back();
					}
				T.node_list[itor->first.get_label()]->successors_ref().push_back(T.node_list[itor->second.get_label()]);
				T.node_list[itor->second.get_label()]->parent_ref() = itor->first.get_label();
				T.node_list[itor->second.get_label()]->level_ref() = T.node_list[itor->first.get_label()]->level_ref() + 1;
			}
			
		}
		
		update_order();
#ifdef DEBUG
		std::cout << "iteration over" << std::endl;
		std::cout << "number of up-edges: " << count << std::endl;
#endif
	}


	
	
}


bool graph::al::SemiTS::is_upedge(edge t)
{
	int source_level = T.node_list[t.first.get_label()]->get_level();
	int target_level = T.node_list[t.second.get_label()]->get_level();
	if (source_level >= target_level)
		return true;
	return false;
}

bool graph::al::SemiTS::is_forwardedge(edge t)
{
	int source_level = T.node_list[t.first.get_label()]->get_level();
	int target_level = T.node_list[t.second.get_label()]->get_level();
	if (source_level < target_level && is_ancestor(T.node_list[t.first.get_label()], T.node_list[t.second.get_label()]))
		return true;
	return false;
}


bool graph::al::SemiTS::is_downedge(edge t)
{
	int source_level = T.node_list[t.first.get_label()]->get_level();
	int target_level = T.node_list[t.second.get_label()]->get_level();
	if (source_level < target_level && !is_ancestor(T.node_list[t.first.get_label()], T.node_list[t.second.get_label()]))
		return true;
	return false;
}

bool graph::al::SemiTS::is_ancestor(level_node* u, level_node* v)
{
	level_node* t = v;
	while (t->get_level() >= u->get_level())
	{
		if (t->get_label() == u->get_label())
			return true;
		t = T.node_list[t->get_parent()];
	}
	return false;
	
}


bool graph::al::SemiTS::is_ingroup(vertex_label_t u, std::vector<vertex_label_t> vec)
{
	for (size_t i = 0; i < vec.size(); i++) {
		if (u == vec[i])
			return true;
	}

	return false;

}


void graph::al::SemiTS::update_order()
{
	std::queue<level_node* > qlist;
	qlist.push(&T.root);
	
	while (!qlist.empty())
	{
		level_node* u = qlist.front();
		qlist.pop();
		
		for (size_t i = 0; i < u->successors_ref().size(); i++)
		{
			if(u->successors_ref()[i]->level_ref() <= u->level_ref())
				u->successors_ref()[i]->level_ref() = u->level_ref() + 1;
			qlist.push(u->successors_ref()[i]);
		}

	}
}

void graph::al::SemiTS::update_order(level_node* u)
{
	std::queue<level_node* > qlist;
	qlist.push(u);
	
	while (!qlist.empty())
	{
		level_node* u = qlist.front();
		qlist.pop();
		
		for (size_t i = 0; i < u->successors_ref().size(); i++)
		{
			if (u->successors_ref()[i]->level_ref() <= u->level_ref())
				u->successors_ref()[i]->level_ref() = u->level_ref() + 1;
			qlist.push(u->successors_ref()[i]);
		}

	}
}

void graph::al::SemiTS::dfs_update(level_node * u, std::vector<color> & status)
{
	status[u->get_label()] = gray;


	for (size_t i = 0; i < u->successors_ref().size(); i++)
	{
		int pos = u->successors_ref()[i]->get_label();
		switch (status[pos])
		{
		case white:
			if (u->get_level() < u->successors_ref()[i]->get_level() - 1) {
				
				//u->successors_ref().erase(u->successors_ref().begin() + i);
				std::swap(u->successors_ref()[i], u->successors_ref()[u->successors_ref().size()-1]);
				u->successors_ref().pop_back();
				i--;
				//tree_edge_num--;
				break;
			}
			dfs_update(u->successors_ref()[i], status);
			break;
		case gray:
		case black:
			if (u->get_level() < u->successors_ref()[i]->get_level() - 1) {
				
				//u->successors_ref().erase(u->successors_ref().begin() + i);
				std::swap(u->successors_ref()[i], u->successors_ref()[u->successors_ref().size()-1]);
				u->successors_ref().pop_back();
				//tree_edge_num--;
				i--;
				break;
			}
	
		}
	}
	
	//std::vector<level_node* >(u->successors_ref()).swap(u->successors_ref());
	status[u->get_label()] = black;
	

}

/*
 *remove_node will casue some internal memory leak, the main reason is that the space of nodes which is removed should be free, but i did't do it
 *At the same time, we read more edges while nodes remove, because we have more internal memory in logic.
 *It is the reason why the internal memory is too high after first iteration, but it not effect the correctness and time of result. Because this operation basically not affect the time. 
 *We do either in other approach.
 **/
void graph::al::SemiTS::remove_node(level_node * u, std::vector<color> & status, int l_min, int& remove_node_num)
{
	status[u->get_label()] = gray;
	bool flag = false;
	for (size_t i = 0; i < u->successors_ref().size(); i++) {
		int pos = u->successors_ref()[i]->get_label();
		switch (status[pos]) {
		case white:
			if (u->successors_ref()[i]->get_level() < l_min) {
			//	std::cout << u->successors_ref()[i]->get_label() << ":" << u->successors_ref()[i]->get_level() << std::endl;
				remove_node(u->successors_ref()[i], status, l_min,remove_node_num);
				remove_node_num++;
				//delete u;


			}
			else {
				flag = true;
			}
			break;
		}
		if (flag)
			break;
	}
	if (flag) {
		for (size_t i = 0; i < u->successors_ref().size() && status[u->successors_ref()[i]->get_label()] == white; i++) {
			T.root.successors_ref().push_back(u->successors_ref()[i]);
			status[u->successors_ref()[i]->get_label()] = gray;
		}
			
	}

	status[u->get_label()] = black;

}
/*
void graph::al::SemiTS::remove_edge(std::string filename)
{
	FILE * file_fd = fopen(filename.c_str(), "r+");
	assert(file_fd);

	long int offset_write = 0;
	long int offset_read = 0;
	size_t len = 4096 + 1;

	char* line = new char[len];
	ssize_t nread;

	nread = getline(&line, &len, file_fd);
#ifdef DEBUG
	io_num++;
	io_read++;
#endif // DEBUG
	while (nread = getline(&line, &len, file_fd) != -1) {
		std::istringstream iss(line);
		edge tmp;
		iss >> tmp.first.label_ref();
		iss >> tmp.second.label_ref();

		if (is_forwardedge(tmp)) {
			if (offset_read == offset_write) {
				offset_write += nread;
				offset_read += nread;
				continue;
			}
			else {
				fseek(file_fd, offset_write, SEEK_SET);
				fputs(line, file_fd);
				offset_write += nread;

				offset_read += nread;
				fseek(file_fd, offset_read, SEEK_SET);
				continue;
			}
		}

		offset_read += nread;
	}

	ftruncate(fileno(file_fd), offset_write);
}
*/









void graph::al::SemiTS::batchSemiTS_it()
{
	bool update = true;

	
	//	int l_max = 0;
	//std::string outfile("final");
	//boost::shared_ptr<std::ofstream> result(new std::ofstream);

	//FILE *result = fopen("final_result", "w+");
	//result->open(outfile.c_str(), std::ios::out);
	dfs dfs_visitor;
	std::vector<vertex_label_t> order;
	int last_min = 0;
	
	while (update == true)
	{
#ifdef DEBUG
		std::cout << "iteration start" << std::endl;
		clock_t start = clock();
#endif // DEBUG

		int l_min = T.num_nodes;
		
		
	
		std::stringstream ss;
		ss << filename ;
		//boost::shared_ptr<std::ofstream> out(new std::ofstream);
		//out->open(ss.str().c_str(), std::ios::out);
		
		int window_ptr = 0;
		update = false;
		edge_iterator  begin(filename.c_str()), end;
		std::vector<color> status;
		int remove_node_num = 0;
		
		std::vector<vertex_label_t >().swap(order);
		//order.assign(T.num_nodes, -1);
		dfs_visitor.dfs_ts(T, order);
		
		for (edge_iterator itor = begin; itor != end; ++itor)
		{
		 
			if (T.node_list[itor->first.get_label()]->get_level() >= last_min && !((dfs_visitor.dtime[itor->first.get_label()]<dfs_visitor.dtime[itor->second.get_label()] && dfs_visitor.ftime[itor->first.get_label()]>dfs_visitor.ftime[itor->second.get_label()]))) {
				
				T.node_list[itor->first.get_label()]->successors_ref().push_back(T.node_list[itor->second.get_label()]);
				//std::cout << "edge:" << itor->first.get_label() << " " << itor->second.get_label() << std::endl;
				window_ptr++;
			}
			
			if (window_ptr == (window_size + remove_node_num))
			{
				
				std::vector<vertex_label_t >().swap(order);
				//order.assign(T.num_nodes, -1);
				dfs_visitor.dfs_ts(T, order);   //attention, 
				std::reverse(order.begin(), order.end());
				
				
				for (size_t i = 0; i < order.size(); i++) {
					for (size_t j = 0; j < T.node_list[order[i]]->successors_ref().size(); j++)
					{
						
						if (T.node_list[order[i]]->successors_ref()[j]->get_level() <= T.node_list[order[i]]->get_level()) {
							l_min = std::min(l_min, T.node_list[order[i]]->successors_ref()[j]->get_level());
							T.node_list[order[i]]->successors_ref()[j]->level_ref() = T.node_list[order[i]]->get_level() + 1;
					
							
							update = true;
						}
						else if (T.node_list[order[i]]->get_level() < T.node_list[order[i]]->successors_ref()[j]->get_level() - 1) {
							//T.node_list[order[i]]->successors_ref().erase(T.node_list[order[i]]->successors_ref().begin() + j);
							std::swap(T.node_list[order[i]]->successors_ref()[j], T.node_list[order[i]]->successors_ref()[T.node_list[order[i]]->successors_ref().size() - 1]);
							T.node_list[order[i]]->successors_ref().pop_back();
							//	tree_edge_num--;
							j--;
						}
					}
				}
				
				
				
				status.assign(T.num_nodes, white);
				
				dfs_update(T.node_list[0], status);
				
				//dfs_visitor.free_space();
				
				window_ptr = 0;
				for (size_t i = 0; i < T.num_nodes; i++)
					std::vector<level_node* >(T.node_list[i]->successors_ref()).swap(T.node_list[i]->successors_ref());
			}
			
		}

		//handle left edges
			if(window_ptr > 0) {
			std::vector<vertex_label_t >().swap(order);
			//order.assign(T.num_nodes, -1);
			dfs_visitor.dfs_ts(T, order);   //attention, 



			std::reverse(order.begin(), order.end());


			for (size_t i = 0; i < order.size(); i++) {
				for (size_t j = 0; j < T.node_list[order[i]]->successors_ref().size(); j++)
				{
					if (T.node_list[order[i]]->successors_ref()[j]->get_level() <= T.node_list[order[i]]->get_level()) {
						l_min = std::min(l_min, T.node_list[order[i]]->successors_ref()[j]->get_level());
						T.node_list[order[i]]->successors_ref()[j]->level_ref() = T.node_list[order[i]]->get_level() + 1;
						//T.node_list[T.node_list[order[i]]->successors_ref()[j]->get_parent()]
						//T.node_list[order[i]]->successors_ref()[j]->parent_ref() = T.node_list[order[i]]->get_label();

						update = true;
					}
					else if (T.node_list[order[i]]->get_level() < T.node_list[order[i]]->successors_ref()[j]->get_level() - 1) {
						//T.node_list[order[i]]->successors_ref().erase(T.node_list[order[i]]->successors_ref().begin() + j);
						std::swap(T.node_list[order[i]]->successors_ref()[j], T.node_list[order[i]]->successors_ref()[T.node_list[order[i]]->successors_ref().size() - 1]);
						T.node_list[order[i]]->successors_ref().pop_back();
						j--;
						tree_edge_num--;
					}
				}
			}


			
			status.assign(T.num_nodes, white);

			dfs_update(T.node_list[0], status);
			

			for (size_t i = 0; i < T.num_nodes; i++)
				std::vector<level_node* >(T.node_list[i]->successors_ref()).swap(T.node_list[i]->successors_ref());
		
			window_ptr = 0;
		}





#ifdef DEBUG
		clock_t handle_edge_time = clock();
		std::cout << "time:" << (double)(handle_edge_time - start) / CLOCKS_PER_SEC << "s" << std::endl;

#endif // DEBUG
		
		
			
		/*
		 *NodeRemove
		 **/
		last_min = l_min;
		std::stringstream s_str;
		status.assign(T.num_nodes, white);
		if (T.root.successors_ref().size() > 0 && T.root.successors_ref()[0]->get_level() < l_min) {
			std::vector<level_node*> list;
			level_node* u;
			for (size_t i = 0; i < T.root.successors_ref().size(); i++) {
				list.push_back(T.root.successors_ref()[i]);
				remove_node_num++;
			}
		
			for (size_t i = 0; i < list.size(); i++) {				
				remove_node(list[i], status, l_min, remove_node_num);
			}
			T.root.successors_ref().erase(T.root.successors_ref().begin(), T.root.successors_ref().begin() + list.size());

			std::vector<level_node* >(T.root.successors_ref()).swap(T.root.successors_ref());
			//tree_edge_num -= list.size();
		}
		T.root.level_ref() = l_min - 1;
		
	

		

		std::vector<color>().swap(status);
#ifdef DEBUG
		clock_t remove_time = clock();
		//	std::wcout << "remove_node:" << rm_node_count << std::endl;
			std::cout << "time:" << (double)(remove_time - handle_edge_time) / CLOCKS_PER_SEC << "s" << std::endl;

#endif // DEBUG
		/*
		int rm_edge_count = 0;
		
		FILE *wt_fd = fopen(ss.str().c_str(), "w+");
		FILE * rd_fd = fopen(filename.c_str(), "r");

		size_t len = BUFSIZ;

		char* wt_buf = new char[BUFSIZ];
		char* line = new char[len];

		int buf_offset = 0;
		int line_offset = 0;
		ssize_t nread;
		//edge_iterator  begin(filename.c_str()), end;
		while(getline(&line, &len, rd_fd) != -1) {

			nread = strlen(line);
#ifdef DEBUG
			io_num += nread;
			io_read += nread;
#endif // DEBUG
			std::istringstream iss(line);
			edge tmp;
			iss >> tmp.first.label_ref();
			iss >> tmp.second.label_ref();

			//hm_itor = remove_map.find(tmp.first.get_label());
			if(T.node_list[tmp.first.get_label()]->get_level() >= l_min && !((dfs_visitor.dtime[tmp.first.get_label()]<dfs_visitor.dtime[tmp.second.get_label()] && dfs_visitor.ftime[tmp.first.get_label()]>dfs_visitor.ftime[tmp.second.get_label()]))) {
				rm_edge_count++;
				if (buf_offset + nread < BUFSIZ) {
					memcpy(wt_buf + buf_offset, line, nread);
					buf_offset += nread;

				}
				else {

					memcpy(wt_buf + buf_offset, line, BUFSIZ - buf_offset);
					line_offset = BUFSIZ - buf_offset;
					buf_offset = nread - line_offset;
					//fputs(wt_buf, wt_fd);
#ifdef DEBUG
					io_num += BUFSIZ;
					io_write += BUFSIZ;
#endif // DEBUG
					fwrite(wt_buf, sizeof(char), BUFSIZ, wt_fd);
					memcpy(wt_buf, line + line_offset, nread - line_offset);
				
					line_offset = 0;
				}
			}
		}
		fwrite(wt_buf, sizeof(char), buf_offset, wt_fd);
#ifdef DEBUG
		io_num += buf_offset;
		io_write += buf_offset;
#endif // DEBUG
		fclose(wt_fd);
		dfs_visitor.free_space();
		delete[]line;
		delete[]wt_buf;
		
		filename = ss.str();
#ifdef DEBUG
		clock_t end_time = clock();
		std::cout << "remove_edge_count:" << rm_edge_count << std::endl;
		std::cout << "time:" << (double)(end_time - start) / CLOCKS_PER_SEC << "s" << std::endl;
		std::cout << "iteration over" << std::endl;
		
#endif // DEBUG

	}*/

	//fclose(result);
		
	}
}




void graph::al::SemiTS::batchSemiTS_judge()
{
	bool update = true;
	int count = 0;
	
	//	int l_max = 0;
	//std::string outfile("final");
	//boost::shared_ptr<std::ofstream> result(new std::ofstream);

	FILE *result = fopen("final_result", "w+");
	//result->open(outfile.c_str(), std::ios::out);
	dfs dfs_visitor;
	std::vector<vertex_label_t> order;
	while (update == true)
	{
#ifdef DEBUG
		std::cout << "iteration start" << std::endl;
		clock_t start = clock();
#endif // DEBUG

		
		
		int l_min = T.num_nodes;
		++count;
		std::stringstream ss;
		ss << filename << count;
		//boost::shared_ptr<std::ofstream> out(new std::ofstream);
		//out->open(ss.str().c_str(), std::ios::out);
		
		int window_ptr = 0;
		update = false;
		edge_iterator  begin(filename.c_str()), end;
		std::vector<color> status;
		int remove_node_num = 0;
		for (edge_iterator itor = begin; itor != end; ++itor)
		{

			//tree_edge_num++;
			/*
			 *we do not check whether is the edge itor is a tree-edge, which means it may exsit repeat edges in T, but we do check it in our comparative algorithm, which not influence the result
			 *
			 **/
			T.node_list[itor->first.get_label()]->successors_ref().push_back(T.node_list[itor->second.get_label()]);
			//std::cout << "edge:" << itor->first.get_label() << " " << itor->second.get_label() << std::endl;
			window_ptr++;
			if (window_ptr == (window_size + remove_node_num))
			{
				
				std::vector<vertex_label_t >().swap(order);
				//order.assign(T.num_nodes, -1);
				dfs_visitor.dfs_ts(T, order);  //attention, 
				
				
				
				std::reverse(order.begin(), order.end());
				
				
				for (size_t i = 0; i < order.size(); i++) {
					for (size_t j = 0; j < T.node_list[order[i]]->successors_ref().size(); j++)
					{
						
						if (T.node_list[order[i]]->successors_ref()[j]->get_level() <= T.node_list[order[i]]->get_level()) {
							l_min = std::min(l_min, T.node_list[order[i]]->successors_ref()[j]->get_level());
							T.node_list[order[i]]->successors_ref()[j]->level_ref() = T.node_list[order[i]]->get_level() + 1;
							//T.node_list[T.node_list[order[i]]->successors_ref()[j]->get_parent()]
							//T.node_list[order[i]]->successors_ref()[j]->parent_ref() = T.node_list[order[i]]->get_label();
							
							update = true;
						}
						else if (T.node_list[order[i]]->get_level() < T.node_list[order[i]]->successors_ref()[j]->get_level() - 1) {
							//T.node_list[order[i]]->successors_ref().erase(T.node_list[order[i]]->successors_ref().begin() + j);
							std::swap(T.node_list[order[i]]->successors_ref()[j], T.node_list[order[i]]->successors_ref()[T.node_list[order[i]]->successors_ref().size() - 1]);
							T.node_list[order[i]]->successors_ref().pop_back();
							//	tree_edge_num--;
								j--;
						}
					}
				}
				
				
				
				status.assign(T.num_nodes, white);
				
				dfs_update(T.node_list[0], status);
				
				//dfs_visitor.free_space();
				
				window_ptr = 0;
				for (size_t i = 0; i < T.num_nodes; i++)
					std::vector<level_node* >(T.node_list[i]->successors_ref()).swap(T.node_list[i]->successors_ref());
			}
			
		}

		//handle left edges
			if(window_ptr > 0) {
			std::vector<vertex_label_t >().swap(order);
			//order.assign(T.num_nodes, -1);
			dfs_visitor.dfs_ts(T, order);  //attention, 



			std::reverse(order.begin(), order.end());


			for (size_t i = 0; i < order.size(); i++) {
				for (size_t j = 0; j < T.node_list[order[i]]->successors_ref().size(); j++)
				{
					if (T.node_list[order[i]]->successors_ref()[j]->get_level() <= T.node_list[order[i]]->get_level()) {
						l_min = std::min(l_min, T.node_list[order[i]]->successors_ref()[j]->get_level());
						T.node_list[order[i]]->successors_ref()[j]->level_ref() = T.node_list[order[i]]->get_level() + 1;
						//T.node_list[T.node_list[order[i]]->successors_ref()[j]->get_parent()]
						//T.node_list[order[i]]->successors_ref()[j]->parent_ref() = T.node_list[order[i]]->get_label();

						update = true;
					}
					else if (T.node_list[order[i]]->get_level() < T.node_list[order[i]]->successors_ref()[j]->get_level() - 1) {
						//T.node_list[order[i]]->successors_ref().erase(T.node_list[order[i]]->successors_ref().begin() + j);
						std::swap(T.node_list[order[i]]->successors_ref()[j], T.node_list[order[i]]->successors_ref()[T.node_list[order[i]]->successors_ref().size() - 1]);
						T.node_list[order[i]]->successors_ref().pop_back();
						j--;
						tree_edge_num--;
					}
				}
			}



			status.assign(T.num_nodes, white);

			dfs_update(T.node_list[0], status);
			

			for (size_t i = 0; i < T.num_nodes; i++)
				std::vector<level_node* >(T.node_list[i]->successors_ref()).swap(T.node_list[i]->successors_ref());
		
			window_ptr = 0;
		}





#ifdef DEBUG
		clock_t handle_edge_time = clock();
		std::cout << "time:" << (double)(handle_edge_time - start) / CLOCKS_PER_SEC << "s" << std::endl;

#endif // DEBUG
		
	
		/*
		 *NodeRemove
		 **/
		std::stringstream s_str;
		status.assign(T.num_nodes, white);
		if (T.root.successors_ref().size() > 0 && T.root.successors_ref()[0]->get_level() < l_min) {
			std::vector<level_node*> list;
			level_node* u;
			for (size_t i = 0; i < T.root.successors_ref().size(); i++) {
				list.push_back(T.root.successors_ref()[i]);
				remove_node_num++;
			}
		
			for (size_t i = 0; i < list.size(); i++) {				
				remove_node(list[i], status, l_min, remove_node_num);
			}
			T.root.successors_ref().erase(T.root.successors_ref().begin(), T.root.successors_ref().begin() + list.size());

			std::vector<level_node* >(T.root.successors_ref()).swap(T.root.successors_ref());
			//tree_edge_num -= list.size();
		}
		T.root.level_ref() = l_min - 1;
		
		//std::vector<vertex_label_t > remove_node;
		//std::tr1::unordered_map<vertex_label_t, int> remove_map;
		//std::tr1::unordered_map<vertex_label_t, int>::iterator hm_itor;
		

		

		std::vector<color>().swap(status);
#ifdef DEBUG
		clock_t remove_time = clock();
		//	std::wcout << "remove_node:" << rm_node_count << std::endl;
			std::cout << "time:" << (double)(remove_time - handle_edge_time) / CLOCKS_PER_SEC << "s" << std::endl;

#endif // DEBUG
		int rm_edge_count = 0;
		
		FILE *wt_fd = fopen(ss.str().c_str(), "w+");
		FILE * rd_fd = fopen(filename.c_str(), "r");

		size_t len = BUFSIZ;

		char* wt_buf = new char[BUFSIZ];
		char* line = new char[len];

		int buf_offset = 0;
		int line_offset = 0;
		ssize_t nread;
		//edge_iterator  begin(filename.c_str()), end;
		while(getline(&line, &len, rd_fd) != -1) {

			nread = strlen(line);
#ifdef DEBUG
			io_num += nread;
			io_read += nread;
#endif // DEBUG
			std::istringstream iss(line);
			edge tmp;
			iss >> tmp.first.label_ref();
			iss >> tmp.second.label_ref();
			int s_level = T.node_list[tmp.first.get_label()]->get_level();
			int e_level = T.node_list[tmp.second.get_label()]->get_level();
			//hm_itor = remove_map.find(tmp.first.get_label());
			if(s_level >= l_min && !((dfs_visitor.dtime[tmp.first.get_label()]<dfs_visitor.dtime[tmp.second.get_label()] && dfs_visitor.ftime[tmp.first.get_label()]>dfs_visitor.ftime[tmp.second.get_label()]) && (s_level < e_level) )){
				rm_edge_count++;
				if (buf_offset + nread < BUFSIZ) {
					memcpy(wt_buf + buf_offset, line, nread);
					buf_offset += nread;
				}
				else {

					memcpy(wt_buf + buf_offset, line, BUFSIZ - buf_offset);
					line_offset = BUFSIZ - buf_offset;
					buf_offset = nread - line_offset;
					//fputs(wt_buf, wt_fd);
#ifdef DEBUG
					io_num += BUFSIZ;
					io_write += BUFSIZ;
#endif // DEBUG
					fwrite(wt_buf, sizeof(char), BUFSIZ, wt_fd);
					memcpy(wt_buf, line + line_offset, nread - line_offset);
				
					line_offset = 0;
				}
			}
		}
		fwrite(wt_buf, sizeof(char), buf_offset, wt_fd);

		fclose(wt_fd);
		dfs_visitor.free_space();
		delete[]line;
		delete[]wt_buf;
		//delete &dfs_visitor;
		
		/*
	
		for (edge_iterator itor = begin; itor != end; ++itor)
		{
			bool tmp_flag1 = false;
			bool tmp_flag2 = false;
			if (dfs_visitor.dtime[itor->first.get_label()]<dfs_visitor.dtime[itor->second.get_label()] &&  dfs_visitor.ftime[itor->first.get_label()]>dfs_visitor.ftime[itor->second.get_label()])
			{
				tmp_flag1 = true;
			}
			
			if (!tmp_flag1) {
				for (size_t i = 0; i < remove_node.size(); i++)
				{

					if (itor->first.get_label() == remove_node[i]){
						tmp_flag2 = true;
						break;
					}
				}
				if (!tmp_flag2) {
#ifdef DEBUG
					io_num++;
					io_write++;
#endif // DEBUG
					*out << itor->first.get_label() << " " << itor->second.get_label() << std::endl;
				}
			}
		}
		*/
		filename = ss.str();
#ifdef DEBUG
		clock_t end_time = clock();
		std::cout << "remove_edge_count:" << rm_edge_count << std::endl;
		std::cout << "time:" << (double)(end_time - start) / CLOCKS_PER_SEC << "s" << std::endl;
		std::cout << "iteration over" << std::endl;
		
#endif // DEBUG

	}

	fclose(result);

		
	}
