#pragma once
#include <iostream>
#include <vector>

#include "types.h"
#include "vertex.h"
#include "spanning_tree.h"
#include "SemiTS.h"

namespace graph {
	namespace al {
		class dfs {
		private:
			//typedef boost::adjacency_list<boost::vecS, boost::vecS, boost::directedS > graph_type;
			typedef  spanning_tree tree_type;
			typedef spanning_tree graph_type;
			typedef std::pair<vertex_label_t, vertex_label_t> edge_type;
			typedef int Time_type;
			
			
			//tree_type g ;

			int num_vertices;
			

			

			

			

		public:
			std::vector<int > height;
			std::vector<Time_type > ftime;
			std::vector<Time_type > dtime;
			std::vector<color> status;
			std::vector<int > etime;
			dfs();
			dfs(int num_vertices);//tree_type& g
			~dfs() {
				//std::vector<color>().swap(status);
				//std::vector<Time_type>().swap(dtime);
				//std::vector<Time_type>().swap(ftime);
			}
			void dfs_lca(graph_type & g, std::vector<int> &euler_tour);
			//tree_type dfs_tree(graph_type& g);
			void dfs_tree(graph_type& g);
			bool is_forward_cross_edge(int s_index, int e_index);
			bool is_backward_edge(int s_index, int e_index);
			//void dfs_travelling(graph_type& g);
			void dfs_node(in_memory_vertex_descriptor *& u, Time_type & clock);
			
			void dfs_ts(lbtree& T, std::vector<vertex_label_t>& order );
			void dfs_travel(lbtree& T);
			void dfs_travel_node(level_node * & u, Time_type & clock);
			void dfs_node(level_node * & u, std::vector<vertex_label_t>& order, Time_type & clock);
			

			void dfs_ts(spanning_tree& T, std::vector<vertex_label_t>& order);
			void dfs_node(in_memory_vertex_descriptor*& u, std::vector<vertex_label_t>& order);


			void dfs_node(in_memory_vertex_descriptor *& u, std::vector<vertex_label_t>& order, bool & flag);
			void dfs_node(in_memory_vertex_descriptor *& u, Time_type & clock, int h, std::vector<int>& euler_tour);
			bool is_cross_edge(int s_index, int e_index);
			void free_space();
			//bool is_cross_edge(edge_type edge);
			//bool is_forward_cross_edge(edge_type edge);
			//bool is_backward_edge(edge_type edge);
			
		};
}

}