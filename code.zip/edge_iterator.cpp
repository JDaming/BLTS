#include "edge_iterator.h"

#include <iostream>
#include <iterator>
#include <cassert>
#include <algorithm>
#include <boost/utility.hpp>
#include <boost/tuple/tuple.hpp>


namespace graph {
	edge_iterator::edge_iterator() {
		is_end_marker = true;
	}

	edge_iterator::edge_iterator(const char* filename) :current_vertex(filename), last_vertex() {
		is_end_marker = false;

		//std::ifstream getnumv(filename);
		//unsigned long numv;

		//getnumv >> numv;

		current_successor_index = -1;
		fetch_next_edge();
	}

	edge_iterator::edge_iterator(const edge_iterator& rhs) {
		*this = rhs;
	}

	

	edge_iterator& edge_iterator::operator = (const edge_iterator& rhs) {
		current_edge = rhs.current_edge;
		current_successor_index = rhs.current_successor_index;
		current_vertex = rhs.current_vertex;
		last_vertex = rhs.last_vertex;
		is_end_marker = rhs.is_end_marker;
		num_vertices = rhs.num_vertices;

		return *this;
	}


	void edge_iterator::fetch_next_edge() {
		assert(!is_end_marker);

		if (current_successor_index < outdegree(current_vertex)) 
			++current_successor_index;
		while (current_successor_index == outdegree(current_vertex)) {
			++current_vertex;
			
			current_successor_index = 0;

			if (current_vertex == last_vertex) {
				this->is_end_marker = true;
				return;
			}
			
			
		}

		assert(0 <= successors(current_vertex)[0]);
		//assert(successors(current_vertex)[0] < num_vertices);

		current_edge = std::make_pair(*current_vertex, successors(current_vertex)[current_successor_index]);

	}

	edge_iterator::~edge_iterator() {

	}
}