#include "obitstream.h"

#include <iostream>

namespace graph {
	/** Writes a byte to the stream.
	*
	* <P>This method takes care of managing the buffering logic transparently.
	*
	* <P>However, this method does <em>not</em> update {@link #writtenBits}.
	* The caller should increment {@link #writtenBits} by 8 at each call.
	*/
	void obitstream::write(const int b) {

		if (avail-- == 0) {
			assert(os != NULL);

			if (no_buffer) {
				os->write((char*)&b, sizeof(b));
				position++;
				avail = 0;
				return;
			}

			// just to make the following a little cleaner..
			std::vector<byte>& buf = *buffer;

			os->write((char*)&buf[0], buf.size());
			position += buf.size();
			avail = buf.size() - 1;
			pos = 0;
		}

		(*buffer)[pos++] = (byte)b;
	}


	/** Writes bits in the bit buffer, possibly flushing it.
	*
	* You cannot write more than {@link #free} bits with this method. However,
	* after having written {@link #free} bits the bit buffer will be empty. In
	* particular, there should never be 0 free bits in the buffer.
	*
	* @param b the bits to write in the <strong>lower</strong> positions;
	* the remaining positions must be zero.
	* @param len the number of bits to write (0 is safe and causes no action).
	* @return the number of bits written.
	*/
	int obitstream::write_in_current(const int b, const int len) {
		current |= (b & ((1 << len) - 1)) << (free -= len);
		if (free == 0) {
			write(current);
			free = 8;
			current = 0;
		}

		written_bits += len;
		return len;
	}

	/** Sets this stream bit position, if it is based on a {@link RepositionableStream} or
	* on a {@link java.nio.channels.FileChannel}.
	*
	* <P>Given an underlying stream that implements {@link
	* RepositionableStream} or that can provide a {@link
	* java.nio.channels.FileChannel} via the <code>getChannel()</code> method,
	* a call to this method has the same semantics of a {@link #flush()},
	* followed by a call to {@link
	* java.nio.channels.FileChannel#position(long) position(position / 8)} on
	* the byte stream. Currently there is no clean, working way of supporting
	* out-of-byte-boundary positioning.
	*
	* @param position the new position expressed as a bit offset; it must be byte-aligned.
	* @throws IllegalArgumentException when trying to position outside of byte boundaries.
	* @throws UnsupportedOperationException if the underlying byte stream does not implement
	*/

	void obitstream::set_position(const long position) {
		assert(position >= 0);
		assert((position & 7) == 0);

		if (wrapping) {
			assert((unsigned long)position <= buffer->size());
			flush();
			free = 8;
			pos = (int)position;
			avail = buffer->size() - pos;
		}
		else {
			flush();
			if (position >> 3 != this->position)
				os->seekp(this->position = position >> 3);
		}
	}

	/** Writes a sequence of bits, starting from a given offset.
	*
	* Bits will be written in the natural way: the first bit is bit 7 of the
	* first byte, the eightth bit is bit 0 of the first byte, the ninth bit is
	* bit 7 of the second byte and so on.
	*
	* @param bits a vector containing the bits to be written.
	* @param offset a bit offset from which to start to write.
	* @param len a bit length.
	* @return the number of bits written (<code>len</code>).
	*/

	int obitstream::write(const byte bits[], const int offset, const int len) {
		const int initial = 8 - (offset & 0x7);
		if (initial == 8)
			return write_byte_offset(bits, offset / 8, len);
		if (len <= initial)
			/// used to be >>>
			return write_int((0xFF & bits[offset / 8]) >> (initial - len), len);
		else
			return write_int(bits[offset / 8], initial) +
			write_byte_offset(bits, offset / 8 + 1, len - initial);
	}

	/** Writes a sequence of bits, starting from a given byte offset.
	*
	* Bits will be written in the natural way: the first bit is bit 7 of the
	* first byte, the eightth bit is bit 0 of the first byte, the ninth bit is
	* bit 7 of the second byte and so on.
	*
	* <p>This method is used to support methods such as {@link #write(byte[],int,int)}.
	*
	* @param bits a vector containing the bits to be written.
	* @param offset an offset, expressed in <strong>bytes</strong>.
	* @param len a bit length.
	* @return the number of bits written (<code>len</code>).
	*/

	int obitstream::write_byte_offset(const byte bits[],
		const int offset, int len) {

		//    	for( int i = 0; i < len/8; i++ )
		//    		cerr << (int)bits[i] << " ";

		//    	cerr << endl;

		if (len == 0) return 0;
		if (len <= free) {
			/// used to be >>>
			// this is okay because bits[] is unsigned, so 0's will be shifted in
			return write_in_current(bits[offset] >> 8 - len, len);
		}
		else {
			const int shift = free;
			int i, j;

			//      cerr << "shift = " << shift << endl;

			// used to be >>>
			write_in_current(bits[offset] >> 8 - shift, shift);

			len -= shift;

			j = offset;
			i = len >> 3;
			while (i-- != 0) {
				// used to be >>>
				write(bits[j] << shift | (bits[j + 1] & 0xFF) >> 8 - shift);
				written_bits += 8;
				j++;
			}

			const int q = len & 7;
			if (q != 0) {
				if (q <= 8 - shift) {
					/// used to be >>>
					write_in_current(bits[j] >> 8 - shift - q, q);
				}
				else {
					write_in_current(bits[j], 8 - shift);
					/// used to be >>>
					write_in_current(bits[j + 1] >> 16 - q - shift, q + shift - 8);
				}
			}

			return len + shift;
		}
	}

	/** Writes a fixed number of bits from an integer.
	*
	* @param x an integer.
	* @param len a bit length; this many lower bits of the first argument will be written
	* (the most significant bit first).
	* @return the number of bits written (<code>len</code>).
	*/

	int obitstream::write_int(int x, const int len) {
		assert(len >= 0 && len <= 32);

		if (len <= free)
			return write_in_current(x, len);

		const int q = (len - free) & 7, blocks = (len - free) >> 3;
		int i = blocks;

		if (q != 0) {
			temp_buffer[blocks] = (byte)x;
			x >>= q;
		}

		while (i-- != 0) {
			temp_buffer[i] = (byte)x;
			// used to be >>>
			x >>= 8;
		}

		write_in_current(x, free);

		for (i = 0; i < blocks; i++)
			//      write( &temp_buffer[ i ], sizeof( temp_buffer[i] )  );
			write(temp_buffer[i]);

		written_bits += blocks << 3;

		if (q != 0)
			write_in_current(temp_buffer[blocks], q);

		return len;
	}

	/** Writes a natural number in unary coding.
	*
	* Note that by unary coding we mean that 1 encodes 0, 01 encodes 1 and so on.
	*
	* @param x a natural number.
	* @return the number of bits written.
	* @throws IllegalArgumentException if you try to write a negative number.
	*/

	int obitstream::write_unary(int x) {
		assert(x >= 0);

		if (x < free) {
			return write_in_current(1, x + 1);
		}
		const int shift = free;
		x -= shift;

		written_bits += shift;
		write(current);
		free = 8;
		current = 0;

		int i = x >> 3;

		written_bits += (x & 0x7FFFFFF8);

		while (i-- != 0)
			write(0);

		write_in_current(1, (x & 7) + 1);

		return x + shift + 1;
	}

}