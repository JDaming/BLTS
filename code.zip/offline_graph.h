#pragma once
#include <string>
#include <fstream>
#include <boost/graph/adjacency_iterator.hpp>
#include <boost/shared_ptr.hpp>

#include "edge_iterator.h"
#include "vertex_iterator.h"
#include "vertex.h"
#include "edge.h"

namespace graph {
	class offline_graph {

	
	public:
		unsigned int n;
		
		unsigned int num_edges;

	public:
		std::string filename;

		offline_graph();
		virtual ~offline_graph();

		static offline_graph load(const std::string& basename);

		//offline_graph& operator =(const offline_graph rhs);
		typedef vertex_iterator node_iterator;
		

		typedef vertex_descriptor vertex_type;
		typedef edge edge_type;

		std::pair<edge_iterator, edge_iterator> get_edge_iterator() const;
		std::pair<vertex_iterator, vertex_iterator> get_vertex_iterator(int from=0) const;

		unsigned int get_num_nodes() const {
			return n;
		}
		
		unsigned int get_num_edges() const {
			return num_edges;
		}

	};
}