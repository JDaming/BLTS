#pragma once
#ifndef INPUT_BITSTREAM_H_
#define INPUT_BITSTREAM_H_

#include <iostream>
#include <vector>
#include <fstream>
#include <cassert>
#include <exception>
#include <boost/shared_ptr.hpp>

#include "types.h"
#include "fast.h"

namespace graph {
	struct eof_exception : public std::exception {
		eof_exception() {}
	};

	class ibitstream {
	public:
		/** The size of the #unget(boolean) buffer in bytes. */
		const static int UNGET_BUFFER_SIZE = 16;
		/** The default size of the byte buffer in bytes (16Ki). */
		const static int DEFAULT_BUFFER_SIZE = 16 * 1024;
	private:
		/** The number of bits actually read from this bit stream. */
		long read_bits;
		/** Current bit buffer: the lowest #fill bits represent the current content
		* (the remaining bits are undefined). */
		int current;
		/** The stream buffer. */

	protected:
		boost::shared_ptr<std::vector<byte> > buffer;
		/** Whether we should use the byte buffer. */
		bool no_buffer;
		/** Current number of bits in the bit buffer (stored low). */
		unsigned int fill;
		/** Current position in the byte buffer. */
		unsigned int pos;
		/** Current number of bytes available in the byte buffer. */
		unsigned int avail;
		/** Current position of the first byte in the byte buffer. */
		unsigned long position;
		/** Byte buffer for ungetting bits. It is allocated on demand. */
		std::vector<byte> unget_bytes;
		/** How many bytes does the unget buffer hold (highest index to go out first) ?. */
		unsigned int unget_count;
		/** Whether we allow overflowing the stream (getting zeroes). */
		bool overflow;
		/** In case we allow overflow, whether we are past EOF. */
		bool past_eof;
		/** True if we are wrapping an array. */
		bool wrapping;



	private:
		/** The stream backing this bit stream */
		boost::shared_ptr<std::istream> is;

		void init() {
			read_bits = 0;
			current = 0;
			no_buffer = true;
			fill = 0;
			pos = 0;
			avail = 0;
			position = 0;
			unget_count = 0;
			overflow = false;
			past_eof = false;
			wrapping = false;
		}

		void init(const boost::shared_ptr<std::istream>& is,
			int buf_size) {
			init();

			this->is = is;
			assert(this->is->good());

			no_buffer = (buf_size == 0);

			assert(buffer->size() == (unsigned)buf_size);
			//      if ( !no_buffer ) 
			//         buffer->resize(buf_size);  			  	
		}

	public:
		ibitstream() {
			init();
		}

		/** Creates a new input bit stream wrapping a given input stream with a specified buffer size.
		*
		* @param is the input stream to wrap.
		* @param bufSize the size in byte of the buffer; it may be 0, denoting no buffering.
		*/
		ibitstream(const boost::shared_ptr<std::istream>& is,
			int buf_size = DEFAULT_BUFFER_SIZE) :
			buffer((buf_size == 0) ? NULL : new std::vector<byte>(buf_size))
		{
			init(is, buf_size);
		}


		/** Creates a new input bit stream reading from a file.
		*
		* @param name the name of the file.
		* @param bufSize the size in byte of the buffer; it may be 0, denoting no buffering.
		*/
		ibitstream(std::string file_name, int buf_size = DEFAULT_BUFFER_SIZE) :
			buffer((buf_size == 0) ? NULL : new std::vector<byte>(buf_size))
		{
			boost::shared_ptr<std::istream> i(new std::ifstream(file_name.c_str()));

			init(i, buf_size);
		}

		~ibitstream() {}

		/**
		* Attaches this input bitstream to the given buffer.
		*/
		/* virtual */
		void attach(boost::shared_ptr<std::vector<unsigned char> > buf) {
			buffer = buf;
			init();

			avail = buf->size();
			no_buffer = false;
			wrapping = true;
		}


		/** Flushes the bit stream. All state information associated to the stream is reset. This
		* includes bytes prefetched from the stream, bits in the bit buffer and unget'd bits.
		*
		* <P>This method is provided so that users of this class can easily wrap repositionable
		* streams (for instance, file-based streams, which can be repositioned using
		* the underlying java.nio.channels.FileChannel). It is guaranteed that after calling
		* this method the underlying stream can be repositioned, and that the next read
		* will draw data from the stream.
		*/

		/* virtual */
		void flush() {
			if (!wrapping) {
				position += pos;
				avail = 0;
				pos = 0;
			}
			fill = 0;
			unget_count = 0;
		}

		void set_overflow(bool overflow) {
			this->overflow = overflow;
		}

		bool get_overflow() {
			return overflow;
		}

		bool get_past_eof() {
			return past_eof;
		}

		long get_read_bits() {
			return read_bits;
		}

		void set_read_bits(long read_bits) {
			this->read_bits = read_bits;
		}
	private:
		int read();
		void refill() {
			assert(fill < 8);

			if (fill == 0) {
				current = read();
				fill = 8;
#ifdef LOGGING
				std::cerr << "\tRefilled from empty; current = " << utils::int_to_binary(current, 8)
					<< "\n";
#endif
			}

			// WATCH watch this part
			if (avail > 0) {
				int r = read();
#ifdef LOGGING
				std::cerr << "\tIn the process of refilling; just fetched "
					<< utils::int_to_binary(r & 0xFF, 8)
					<< "\n";
#endif
				current = (current << 8) | r;
				fill += 8;
#ifdef LOGGING
				std::cerr << "Refilled from partially full; current = "
					<< utils::int_to_binary(current, fill)
					<< "\n";
#endif
			}
			else {
				// we know we have to read a file, so catch that pesky eof exception
				try {
					int r = read();
#ifdef LOGGING
					std::cerr << "\tIn the process of refilling; just fetched "
						<< utils::int_to_binary(r & 0xFF, 8)
						<< "\n";
#endif
					current = (current << 8) | r;
					fill += 8;
#ifdef LOGGING
					std::cerr << "Refilled from partially full; current = "
						<< utils::int_to_binary(current, fill)
						<< "\n";
#endif      
				}
				catch (eof_exception e) {
					// don't care.
				}
			}
		}

		int read_from_current(unsigned int len);

		void align() {
			if ((fill & 7) == 0) return;
			read_bits += fill & 7;
			fill &= ~7;
		}
	public:
		void read(byte bits[], unsigned int len);
		int read_bit() {
			return read_from_current(1);
		}
		int read_int(unsigned int len);
		long skip(unsigned long n);
		void set_position(unsigned long position);


	};
}


#endif